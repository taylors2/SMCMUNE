#include<Rmath.h>
#include<R.h>
#include<R_ext/Applic.h>
#include<Rinternals.h>
#include<R_ext/Rdynload.h>


#ifndef NULL
# define NULL 0
#endif

//Stucture for storing addresses and general information about state posteriors
typedef struct _PostInfo {
        double **ppPost;        //Vector of pointers to posterior surfaces (log scale)
        double *pNorm;          //Vector of normalising constants (log scale)
        int *pInUse;            //Vector of logicals (P_Manage)
        int nmax;               //Maximum number of posteriors that can be assigned
        int nallocated;         //Number of allocated spaces (H)
        int GridSize;           //Size of a single posterior
        } PostInfo;

//Static variables for containing and managing the call stack.
static char callstack[1000] = "\n\0";
static char *pcallstack = &(callstack[0]);
static int istack = 2;

//List of functions

void InitialisePostInfo( PostInfo *pPI, int maxsize, int GridSize );
int CreateSinglePostInfo( PostInfo *pPI );
void NotInUsePostInfo( PostInfo *pPI, int index );
void CopyToPost( PostInfo *pPI, int to, double *pfrom );
double* UsePostAddress( PostInfo *pPI, int index );
void FreeAllPostInfo( PostInfo *pPI );
void Trapezium_Rule_V2(double *logpts, double *cellvol, int *n, int *dim, int *npts,
                    double *lognorm, double *logexpect, int *LOG, double *out);
void Simpsons_Rule_V2(double *logpts, double *cellvol, int *n, int *dim, int *npts,
                    double *lognorm, double *logexpect, int *LOG, double *out);
void INTEGRATE_V2(char **METHOD, double *lpts, double *cellvol, int *n, int *dim, int *npts,
                    double *lnorm, double *lexpect, int *LOG, double *out);
void LogLogisticSigmoid( double *x, double *loc, double *rate, int *calcx, int *Log, int *nout, double *out);
void TICKER( int *now, int *used, int *max, int *U );
void Vectorised_KtC(double *Cvec, int *K, int *u, double *out);
void Vectorised_KtCK(double *C, int *K, int *u, double *out);
void Update_Baseline(double *Zi, double *y);
void Update_Nonbaseline(double *Zi, double *mb, double *y, int *K, int *u);
void Update_Ph( double *LogP_pts, double *Prob_pts, int *K_event, int *npts, double *out);
void Update_P( PostInfo *pPI, int *pZst, int *pK, double *pS, int *pN, int *pU,
                 double *pG, int *pGnpts, char **ppFN, int *poutK1, int *poutK0 );
void Update_PNorms( PostInfo *pPI, char **ppIntMethod, double *pGcellvol, int *pGn,
                   int *pGdim, int *pGnpts, double *pZeroVec );
void Update_Zobs(double *y, double *Zobs, int *K, int *N, int *u, int *dzobs);
void Update_Zst( int *pZst, int *pK, int *pLabK0, int *pLabK1, int *pU, int *pN );
void Initialise_P_V2( double *grid, int *n, int *dim, double *alpha, double *beta, int *LOG, double *out);
void Initialise_P0_V3(double *pSb, double *pSmax, int *pnb, double *pG, int *pGdim,
        int *pGnpts, double *pGcellvol, int *pGn, double *pAlpha, double *pBeta, char **ppFN,
        char **ppMETHOD, int *pLOG, int *pU, double *pMargPart, double *pout);
void Make_Regular_Grid(int *n, int *dim, int *nopts, double *lower, double *upper, double *out);
void Initialise_ZObs_V2(double *pYbase, double *pYmax, int *pnb, double *pZstar, 
                    double *pbinfo, int *pU, int *pN, int *pdzi, double *pMargPart,
                    double *pout, double *pb0, double *phatnub );
void Initialise_ZSt( int *h, int *u, int *N, int *out);
void dnonstdt(double *x, double *mu, double *sigma, double *df, int *LOG, double *out);
void Marginalise_K( double *probs, int *kdim, int *N, double *out );
void Pred_Kvec_ij( double *probs1, double *probs0, int *Zsti, int *Kj, int *u, int *LOG, double *out);
void tMU(double *Zi, int *K, int *u, int *BASELINE, double *out);
void tSIGMA(double *Zi, int *K, int *u, int *BASELINE, double *out);
void tDF(double *Zi, int *u, int *BASELINE, double *out);
void Predictive_ObsProcess_ij(double *Zi, double *y, int *K, int *u, int *LOG, double *out);
void Pred_Yt_i(double *y, double *Zobsi, int *Zsti, double *probs1, double *probs0, int *u,
                    int *kdim, double *out);
void Pred_Yt(double *y, double *Zobs, int *Zst, double *probs1, double *probs0, int *u,
                    int *kdim, int *nZobsi, int *N, double *out);
void Prob_Fire_V2(double *S, PostInfo *pPI, char **METHOD, char **ppFN, double *Grid, 
                  double *cellvol, int *n, int *dim, int *npts, double *out0, double *out1);
void Expects_By_Store( PostInfo *pPI, double *pG, int *pParam, double *pOrder, 
                       char **ppMETHOD, double *pGcellvol, int *pGn, int *pGdim,
                        int *pGnpts, double *pout );
void ORDER( double *Expects, int *Zst, int *U, int *N, int *out);
void Sym_Mat_Inds( int *U, int *out );
void ORDER_C_IND( int *ORD, int *IND, int *U, int *out );
void ORDER_Zobs( double *Z, int *Ords, int *U, int *N, int *dZ);
void ORDER_ZST(int *ZST, int *ORD, int *U, int *N);
void Table_UnitVsHist(int *Zst, int *N, int *U, int *H, int *out);
void Marg_Pred( double *weights, int *N, int *LOG, double *out, double *pNeff);
void Resample(double *weights, int *N, char **METHOD, int *out);
void SimpleResample(double *pweights, double *ptotal, int *N, int *M, int *pout);
void StratResample(double *pweights, double *ptotal, int *N, int *M, int *pout);
void SysResample(double *pweights, double *ptotal, int *N, int *M, int *pout);
void Reorder_Pmanage( PostInfo *pPI, int *pZst, int *pU, int *pN );
void Reorder_Zobs(int *zeta, double *Zobs, int *N, int *dZobs, double *out);
void Reorder_Zst(int *zeta, int *Zst, int *N, int *u, int *out);
void SampleKi_V2(double *probi, int *kdim, int *u, int *out);
void SampleK( double *probs, int *zeta, int *N, int *Kdim, int *u, int *out);
void THRESHOLD( char **ppFN, double *px, double *pG, int *pGnpts,
        int *pFixParams, int *pLOG, int *pnout, double *pout);
void GaussianSigmoid( double *x, double *loc, double *sd, int *calcx, int *Log, int *nout, double *out);
void ProbCheck( double *pprobs, int *pInUse, int *pn );
void CallStackAdd( char *pName );
void CallStackRm( char *pName );
void *my_malloc(size_t n);
void my_free( void *p);
int NoGrids( PostInfo *pPI );
void Export_Zall( double *pZobs, int *pZst, int *pdZobs, int *pN, int *pU);
void Export_GandPs( PostInfo *pPI, double *pG, int *pGdim );
void Export_ZobsNB_curr( double *pZobs, int *pZst, int *pdZobs, int *pN, int *pU, int *pt);

/* MUNE_U **********************************************************************
* Description:                                                                 *
*    Performs a particle learning algorithm to sequentially fit the MUNE model *
*    that assumes the existance of U motor units. This command returns the     *
*    logged marginal predictive for all of the observations, given the data    *
*    that preceeds it, and if required the expected vaule, the standard        *
*    deviation, the median estimate and any other quantiles for each of the    *
*    parameters.                                                               *
* INPUT:                                                                       *
*    pY = CMAP responses                                                       *
*    pS = the administered stimuli                                             *
*    pnobs = number of observations                                            *
*    pYbase = the baseline responses (training data)                           *
*    pSbase = the stimuli for the baseline responses                           *
*    pYmax = a single supramaximal stimulated response (training data)         *
*    pSmax = the supramaximal stimulus                                         *
*    pnbase = number of baseline responses                                     *
*    pU = number of motor units                                                *
*    pN = number of particles                                                  *
*    pZstar = the intial values for the ESV, both baseline and not             *
*    pGlow = lower bound for state parameter space grid                        *
*    pGupp = upper bound for state parameter space grid                        *
*    pGn = number of points in each dimension of state parameter space grid    *
*    pGdim = number of parameters that describe the threshold function         *
*    pOrdBy = which state parameter to order motor units by (default: first)   *
*    pPalpha = alpha parameters for the Scaled-Beta prior on state parameters  *
*    pPbeta = beta parameters for the Scaled-Beta prior on state parameters    *
*    ppIntMethod = Integration Method {Trapezium_Rule or Simpsons_Rule}        *
*    ppResampMethod = Resampling Method {Multinomial or Residual}              *
*    ppFN = Threshold function {Log-Logistic or Gaussian}                      *
*    pexportall = logical, save GandP data                                     *
*    pSeqOut = logical, save sequential Z stats                                *
* FN USES:                                                                     *
*    Make_Regular_Grid, InitialisePostInfo, CreateSinglePostInfo, CopyToPost   *
*    Initialise_P0_V3, INTEGRATE_V2, Initialise_ZObs_V2, Initialise_ZSt, TICKER*
*    Prob_Fire_V2, ProbCheck, Pred_Yt, Marginalise_K, Marg_Pred, Resample      *
*    Reorder_Zobs, Reorder_Zst, Reorder_Pmanage, SampleK, Update_Zobs, Update_P*
*    Update_PNorms, Update_Zst, Expects_By_Store, ORDER, ORDER_ZST, ORDER_Zobs *
*    SIMULATE_UNKNOWNS, Export_ZobsNB, NoGrids, Export_NoGrids                 *
*    Export_Neff, Export_Zall, Export_GandPs, Export_ZobsNB_curr               *
* FN USED BY:                                                                  *
*    None (Called externally)                                                  *
*******************************************************************************/

void MUNE_U( 
    double *pY,               //[1]
    double *pS,               //[2]
    int *pnobs,               //[3]
    double *pYbase,           //[4]
    double *pSbase,           //[5]
    double *pYmax,            //[6]
    double *pSmax,            //[7]
    int *pnbase,              //[8]
    int *pU,                  //[9]
    int *pN,                  //[10]
    double *pZstar,           //[11]
    double *pbinfo,           //[12]
    double *pGlow,            //[13]
    double *pGupp,            //[14]
    int *pGn,                 //[15]
    int *pGdim,               //[16]
    int *pOrdBy,              //[17]
    double *pPalpha,          //[18]
    double *pPbeta,           //[19]
    char **ppIntMethod,       //[20]
    char **ppResampMethod,    //[21]
    char **ppFN,              //[22]
    int *pexportall,          //[23] (for GandPs)
    int *pSeqOut,             //[24]
    double *pout_marg,        //[25]
    double *pNEFF,            //[26]
    int *pnCurrGrids,          //[27]
    double *pb0,              //[28]
    double *phatnub           //[29]
 ){
    
    CallStackAdd( "MUNE_U" );
    int t, d, h;     //Looping variables (time/state params/posterior surfaces)
    int ticker;      //used in printing the progress bar
    int Gnpts;       //Overall number of points in state parameter space grid
    int True=TRUE;   //TRUE argument as number i.e. 1
    int dZobs;       //length of obs. process of the essential state vector
    int Kdim;        //size of the firing index vector event space
    int *pZst, *pZstTMP, *pb;       
                     //the state process subset of the essential state vector 
                     //    and related tempory values
    int *pZeta;      //Resampling indices
    int *pK;         //Sampled firing index vectors
    int *pLabK0, *pLabK1;
                     //Used to govern how the posterior surfaces are to be updated

    double Gcellvol; //Volume of a cell in the state parameter grid
    double *pG;      //State parameter grid
    double *pPtmp;   //Temporay object needed in initialisation
    double *pZeroVec;//vector of zeros of length Gnpts
    double *pMargObsb, *pMargStb;
                     //Tempory objects containing marginal likelihood estimate
                     //   components relating to the calibration data
    double *pZobs, *pZobsTMP, *pa;
                    //the observation process subset of the essential state vector
                    //    and related tempory values
    double *pProbFire1, *pProbFire0;
                    //the predictive firing probability for each posterior surface
    double *pProbYK_Z;
                    //Joint predictive probabilities
    double *pOmega; //Unnormalised resampling weights
    
    PostInfo *pPI;  //Structure for the posterior surfaces

    //ONLY USED IF THERE ARE MORE THAN ONE MOTOR UNIT
    int *pORDS;         //For ordering the motor units
    double moment=1.0;  //For evaluating the first moment of parameter estimate
    double *pExp_Phi;   //Expected parameter value for ordering motor units

    //Calc. Gnpts and Gcellvol and create regular grid
    Gnpts = pGn[0];
    Gcellvol = (pGupp[0] - pGlow[0])/(pGn[0]-1);
    for(d=1;d<*pGdim;d++){
        Gnpts *= pGn[d];
        Gcellvol *= (pGupp[d] - pGlow[d])/(pGn[d]-1);
    }
    pG = my_malloc( (*pGdim) * Gnpts * sizeof(double) );
    Make_Regular_Grid( pGn, pGdim, &Gnpts, pGlow, pGupp, pG );
    
    //Allocate memory for PostInfo and initialise the first posterior surface
    pPI = (PostInfo*)my_malloc(sizeof(PostInfo));
    InitialisePostInfo( pPI, (*pU)*(*pN), Gnpts );
    h = CreateSinglePostInfo( pPI );
    
    pPtmp = (double *)my_malloc( Gnpts * sizeof(double) );
    pMargStb = (double *)my_malloc( (1 + *pnbase) * sizeof(double) );
    Initialise_P0_V3( pSbase, pSmax, pnbase, pG, pGdim, &Gnpts, &Gcellvol, pGn, pPalpha,
        pPbeta, ppFN, ppIntMethod, &True, pU, pMargStb, pPtmp );
    CopyToPost( pPI, h , pPtmp );
    my_free(pPtmp);
    
    pZeroVec = (double *)my_malloc( Gnpts * sizeof(double) );
    for(d=0;d<Gnpts;d++){pZeroVec[d]=0;}
    INTEGRATE_V2( ppIntMethod, pPI->ppPost[h], &Gcellvol, pGn, pGdim, &Gnpts, pZeroVec, pZeroVec, &True, &(pPI->pNorm[h]));
        
    //Create and Initialise Essential State Vectors
    dZobs =  6 + (int)( (*pU) * (*pU + 3) / 2 );
    pZobs = (double *)my_malloc( (*pN) * dZobs * sizeof(double) );
    pMargObsb = (double *)my_malloc( (1 + *pnbase) * sizeof(double) );
    Initialise_ZObs_V2( pYbase, pYmax, pnbase, pZstar, pbinfo, pU, pN, &dZobs, pMargObsb, pZobs, pb0, phatnub );    
    pZst = (int *)my_malloc( (*pN) * (*pU) * sizeof(int) );
    Initialise_ZSt( &h, pU, pN, pZst);

    //Calculate the marginal predictives for the calibration data
    for(t=0;t<(*pnbase+1);t++){
        pout_marg[t] = pMargObsb[t] + pMargStb[t];
    }
    my_free(pMargObsb);
    my_free(pMargStb);
    
    //Evaluate Misc. Values
    Kdim = (int) pow(2,*pU);
    
    //t LOOP
    t = -1;
    ticker = -1;
    TICKER( &t, &ticker, pnobs, pU);
    for(t=0; t<*pnobs; t++){
        if(*pSeqOut == TRUE){
            Export_ZobsNB_curr( pZobs, pZst, &dZobs, pN, pU, &t);
        }
        TICKER( &t, &ticker, pnobs, pU);
        
        //Calc. Predictive
        pProbFire0 = (double *)my_malloc( (pPI->nallocated) * sizeof(double) );
        pProbFire1 = (double *)my_malloc( (pPI->nallocated) * sizeof(double) );
        pProbYK_Z = (double *)my_malloc( Kdim * (*pN) * sizeof(double) );
        pOmega = (double *)my_malloc( (*pN) * sizeof(double) );
        
        Prob_Fire_V2(&(pS[t]), pPI, ppIntMethod, ppFN, pG, &Gcellvol, pGn, pGdim, &Gnpts, pProbFire0, pProbFire1 );
        ProbCheck( pProbFire1, pPI->pInUse, &(pPI->nallocated) );
        ProbCheck( pProbFire0, pPI->pInUse, &(pPI->nallocated) );
        Pred_Yt( &(pY[t]), pZobs, pZst, pProbFire1, pProbFire0, pU, &Kdim, &dZobs, pN, pProbYK_Z);
        Marginalise_K( pProbYK_Z, &Kdim, pN, pOmega );
        
        my_free(pProbFire0);
        my_free(pProbFire1);

        //Calc. Marginal Predictive
        Marg_Pred( pOmega, pN, &True, &(pout_marg[1+*pnbase+t]), &(pNEFF[t]) );
        
        //Resample Particles        
        pZeta = (int *)my_malloc( *pN * sizeof(int));
        Resample( pOmega, pN, ppResampMethod, pZeta );
        my_free(pOmega);
        
        pZobsTMP = (double *)my_malloc( (*pN) * dZobs * sizeof(double) );
        Reorder_Zobs( pZeta, pZobs, pN, &dZobs, pZobsTMP );
        pa = pZobs;
        pZobs = pZobsTMP;
        my_free(pa);
        
        pZstTMP = (int *)my_malloc( (*pN) * (*pU) * sizeof(int) );
        Reorder_Zst( pZeta, pZst, pN, pU, pZstTMP );
        pb = pZst;
        pZst = pZstTMP;
        my_free(pb);
                
        Reorder_Pmanage( pPI, pZst, pU, pN );
        
        //Sample K
        pK = (int *)my_malloc( (*pN) * (*pU) * sizeof(int) );
        SampleK( pProbYK_Z, pZeta, pN, &Kdim, pU, pK );
        my_free(pZeta);
        my_free(pProbYK_Z);
        
        //Update
        Update_Zobs( &(pY[t]), pZobs, pK, pN, pU, &dZobs);
        pLabK0 = (int *)my_malloc( pPI->nallocated * sizeof(int));
        pLabK1 = (int *)my_malloc( pPI->nallocated * sizeof(int));
        Update_P( pPI, pZst, pK, &(pS[t]), pN, pU, pG, &Gnpts, ppFN, pLabK1, pLabK0 );
        Update_PNorms( pPI, ppIntMethod, &Gcellvol, pGn, pGdim, &Gnpts, pZeroVec );
        Update_Zst( pZst, pK, pLabK0, pLabK1, pU, pN );
        
        my_free(pLabK0);
        my_free(pLabK1);
        my_free(pK);
        
        //Reorder Motor Units
        if(*pOrdBy >= 0){
            if(*pU>1){
                pExp_Phi = (double *)my_malloc( pPI->nallocated * sizeof(double) );
                pORDS = (int *)my_malloc( (*pN) * (*pU) * sizeof(int) );
                Expects_By_Store( pPI, pG, pOrdBy, &moment, 
                           ppIntMethod, &Gcellvol, pGn, pGdim, &Gnpts, pExp_Phi );
                ORDER( pExp_Phi, pZst, pU, pN, pORDS );
                ORDER_ZST( pZst, pORDS, pU, pN );
                ORDER_Zobs( pZobs, pORDS, pU, pN, &dZobs );
                my_free(pORDS);
                my_free(pExp_Phi);
            }
        }
        
        //Determine the number of active surfaces
        pnCurrGrids[t] = NoGrids( pPI );

    }
    //Always export the last NB info for adjustment calculation
    /* Not required, this is being managed elsewhere!!!*/
    //Export_ZobsNB_curr( pZobs, pZst, &dZobs, pN, pU, &t); 
    
    TICKER( pnobs, &ticker, pnobs, pU);
            
    //Export all of the Final Information
    Export_Zall( pZobs, pZst, &dZobs, pN, pU);
    if( *pexportall == TRUE ){
      Export_GandPs( pPI, pG, pGdim );   //GandPs?
    }
        
    //Free all allocated memory blocks
    my_free(pZst);
    my_free(pZobs);
    my_free(pZeroVec);
    FreeAllPostInfo(pPI);
    my_free(pG);
    my_free(pPI);
    CallStackRm( "MUNE_U" );
}

/* InitialisePostInfo **********************************************************
* Description:                                                                 *
*    Allocateds space and initialises the structure for the posterior surfaces *
* INPUT:                                                                       *
*    pPI = Structure                                                           *
*    maxsize = the maximum number of posteriors that are allowed (U*N)         *
*    GridSize = number of points in the surface (Gnpts)                        *
* FN USES: None                                                                *
* FN USED BY:                                                                  *
*    MUNE_U                                                                    *
*******************************************************************************/

void InitialisePostInfo( PostInfo *pPI, int maxsize, int GridSize ){
    CallStackAdd( "InitialisePostInfo" );
    int i;
    pPI->ppPost = (double **)my_malloc( maxsize * sizeof(double*) );
    pPI->pInUse = (int*)my_malloc( maxsize * sizeof(int) );
    pPI->pNorm = (double*)my_malloc( maxsize * sizeof(double) );
    pPI->nmax = maxsize;
    pPI->nallocated = 0;
    pPI->GridSize = GridSize;
    for(i=0;i<maxsize;i++){
        pPI->ppPost[i] = NULL;
        pPI->pInUse[i] = FALSE;
        pPI->pNorm[i] = NA_REAL;
    }
    CallStackRm( "InitialisePostInfo" );
}

/* CreateSinglePostInfo ********************************************************
* Description:                                                                 *
*    Finds the first available space and allocates memory such that the new    *
*    information can be entered. Consequently, various other values in the     *
*    PostInfo structure are defined/updated.                                   *
* INPUT:                                                                       *
*    pPI = Structure                                                           *
* FN USES: None                                                                *
* FN USED BY:                                                                  *
*    MUNE_U, Update_P                                                          *
*******************************************************************************/

int CreateSinglePostInfo( PostInfo *pPI ){
    CallStackAdd( "CreateSinglePostInfo" );
    int i;
    i=0;
    while( (pPI->pInUse[i]==TRUE) && (i < (pPI->nmax)) ){
        i++;
    }
    if(i == (pPI->nmax) ){
        error("Unable to create an additional posterior surface. Call stack%s\n",pcallstack);
    }
    if( pPI->ppPost[i] != NULL ){
        error("Attempting to allocate memory using a non-NULL pointer. Call stack%s\n",pcallstack);
    }
    pPI->ppPost[i] = (double*)my_malloc( pPI->GridSize * sizeof(double) );
    if( i == (pPI->nallocated) ){
        pPI->nallocated++;
    }
    pPI->pInUse[i] = TRUE;
    pPI->pNorm[i] = R_NegInf;
    CallStackRm( "CreateSinglePostInfo" );
    return i;
}

/* NotInUsePostInfo ************************************************************
* Description:                                                                 *
*    For a supplied label, the memory for its posterior surface is de-allocated*
*    and the associated variables are re-set.                                  *
* INPUT:                                                                       *
*    pPI = Structure                                                           *
*    index = label the defined which posterior to de-allocate                  *
* FN USES: None                                                                *
* FN USED BY:                                                                  *
*    FreeAllPostInfo, Reorder_Pmanage                                          *
*******************************************************************************/

void NotInUsePostInfo( PostInfo *pPI, int index ){
    CallStackAdd( "NotInUsePostInfo" );
    pPI->pInUse[index] = FALSE;
    pPI->pNorm[index] = NA_REAL;
    my_free(pPI->ppPost[index]);
    pPI->ppPost[index]=NULL;
    CallStackRm( "NotInUsePostInfo" );
}

/* CopyToPost ******************************************************************
* Description:                                                                 *
*    Coppies a pre-defined posterior surface into the defined space in the     *
*    in the structure.                                                         *
* INPUT:                                                                       *
*    pPI = Structure                                                           *
*    to = numeric label stating which memory to paste to                       *
*    pfrom = pointer to the object to copy                                     *
* FN USES:                                                                     *
*    UsePostAddress                                                            *
* FN USED BY:                                                                  *
*    MUNE_U, Update_P                                                          *
*******************************************************************************/

void CopyToPost( PostInfo *pPI, int to, double *pfrom ){
    CallStackAdd( "CopyToPost" );
    int i;
    double *address;
    if( pPI->ppPost[to] == NULL ){
        error("Trying to use a NULL pointer. Call stack%s\n",pcallstack);
    };
    address = UsePostAddress( pPI, to );
    for(i=0;i<(pPI->GridSize);i++){
        address[i] = pfrom[i];
    }
    CallStackRm( "CopyToPost" );
}

/* UsePostAddress **************************************************************
* Description:                                                                 *
*    Returns the address for the specified posterior surface                   *
* INPUT:                                                                       *
*    pPI = Structure                                                           *
*    index = numeric label stating the posterior of interest                   *
* FN USES: None                                                                *
* FN USED BY:                                                                  *
*    CopyToPost, MyQuantiles_ST_NEW                                            *
*******************************************************************************/

double* UsePostAddress( PostInfo *pPI, int index ){
    return pPI->ppPost[index];
}

/* FreeAllPostInfo *************************************************************
* Description:                                                                 *
*    De-allocates all memory that has been assigned for the PostInfo structure *
* INPUT:                                                                       *
*    pPI = Structure                                                           *
* FN USES:                                                                     *
*    NotInUsePostInfo                                                          *
* FN USED BY:                                                                  *
*    MUNE_U                                                                    *
*******************************************************************************/

void FreeAllPostInfo( PostInfo *pPI ){
    CallStackAdd( "FreeAllPostInfo" );
    int i;
    for(i=0;i<(pPI->nallocated);i++){
        if(pPI->pInUse[i]==TRUE){
            if(pPI->ppPost[i] == NULL){
                error("Trying to free allocated memory using a NULL pointer. Call stack%s\n",pcallstack);
            };
            NotInUsePostInfo( pPI, i );
        }
    }
    my_free(pPI->pNorm);
    my_free(pPI->pInUse);
    my_free(pPI->ppPost);
    CallStackRm( "FreeAllPostInfo" );
}

/* Trapezium_Rule_V2 ***********************************************************
*  INPUT:                                                                      *
*    logpts = logged point values of the posterior surface                     *
*    cellvol = cell volume used in Grid                                        *
*    n = number of points in each dimension of Grid                            *
*    dim = number of dimensions in Grid                                        *
*    npts = n * dim                                                            *
*    lognorm = logged normalising constant for each posterior plvals           *
*    logexpect = logged values to include for evaluating expectations          *
*    LOG = logical vector stating whether ouput should be logged               *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Performs numerical integration using the Trapezium Rule. It calculates:   *
*    E[ g(PHI) | Z_{t-1}^{(i)} ]                                               *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    INTEGRATE_V2                                                              *
*******************************************************************************/

void Trapezium_Rule_V2(double *logpts, double *cellvol, int *n, int *dim, int *npts,
                    double *lognorm, double *logexpect, int *LOG, double *out){
    CallStackAdd( "Trapezium_Rule_V2" );
    int tick[*dim], i, d;
    double wt, tmp;
    
    *out = 0;
    for(d=0;d<*dim;d++){
        tick[d]=0;
    }
    for(i=0;i<*npts;i++){
        if( R_FINITE(logpts[i]) && R_FINITE(logexpect[i]) ){
            wt = 0;
            for(d=0;d<*dim;d++){
                if(tick[d]==0 || tick[d]==(n[d]-1)){
                    wt = wt - log(2);
                }
            }
            tmp = exp(wt + logpts[i] + logexpect[i]);
            *out = *out + tmp;
        }
        tick[0]++;
        for(d=0;d<(*dim-1);d++){
            if(tick[d]==n[d]){
                tick[d+1]++;
                tick[d]=0;
            }
        }
    }
    if(*LOG == TRUE){
        *out = log(*cellvol) + log(*out) - (*lognorm);
    }
    else if(*LOG==FALSE){
        *out = ((*cellvol) * (*out))/exp(*lognorm);
    }
    else{
        *out = NA_REAL;
        Rprintf("Trapezium_Rule_V2: 'log' term not logical!\n");
    }
    CallStackRm( "Trapezium_Rule_V2" );
}


/* Simpsons_Rule_V2 ************************************************************
*  INPUT:                                                                      *
*    logpts = logged point values of the posterior surface                     *
*    cellvol = cell volume used in Grid                                        *
*    n = number of points in each dimension of Grid                            *
*    dim = number of dimensions in Grid                                        *
*    npts = n * dim                                                            *
*    lognorm = logged normalising constant for each posterior plvals           *
*    logexpect = logged values to include for evaluating expectations          *
*    LOG = logical vector stating whether ouput should be logged               *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Performs numerical integration using the Simpson's Rule. It calculates:   *
*    E[ g(PHI) | Z_{t-1}^{(i)} ]                                               *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    INTEGRATE_V2                                                              *
*******************************************************************************/

void Simpsons_Rule_V2(double *logpts, double *cellvol, int *n, int *dim, int *npts,
                    double *lognorm, double *logexpect, int *LOG, double *out){
    CallStackAdd( "Simpsons_Rule_V2" );
    int tick[*dim], i, d;
    double wt, tmp;
    
    *out = 0;
    for(d=0;d<*dim;d++){
        tick[d]=0;
    }
    
    for(i=0;i<*npts;i++){
        if( R_FINITE(logpts[i]) && R_FINITE(logexpect[i]) ){        
            wt = 0;
            for(d=0;d<*dim;d++){
                if(tick[d]==0 || tick[d]==(n[d]-1)){
                    wt = wt - log(3);
                }
                else if( tick[d]%2 == 0){
                    wt = wt + log(2) - log(3);
                }
                else{
                    wt = wt + log(4) - log(3);
                }
            }
            tmp = exp( wt + logpts[i] + logexpect[i]);
            *out = *out + tmp;
        }
        tick[0]++;
        for(d=0;d<(*dim-1);d++){
            if(tick[d]==n[d]){
                tick[d+1]++;
                tick[d]=0;
            }
        }
    }
    if(*LOG == TRUE){
        *out = log(*cellvol) + log(*out) - (*lognorm);
    }
    else if(*LOG==FALSE){
        *out = ((*cellvol) * (*out))/exp(*lognorm);
    }
    else{
        *out = NA_REAL;
        Rprintf("Simpsons_Rule_V2: 'log' term not logical!\n");
    }
    CallStackRm( "Simpsons_Rule_V2" );
}

/* INTEGRATE_V2 ****************************************************************
*  INPUT:                                                                      *
*    METHOD = the integration method to perform                                *
*    lpts = logged point values of the posterior surface                       *
*    cellvol = cell volume used in Grid                                        *
*    n = number of points in each dimension of Grid                            *
*    dim = number of dimensions in Grid                                        *
*    npts = n * dim                                                            *
*    lnorm = logged normalising constant for each posterior plvals             *
*    lexpect = logged values to include for evaluating expectations            *
*    LOG = logical vector stating whether ouput should be logged               *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Wrapper for the integration procedure. Only two methods are accepted:     *
*    the trapezium and Simpson's rule                                          *
*  FN USES:                                                                    *
*     Trapezium_Rule_V2                                                        *
*     Simpsons_Rule_V2                                                         *
*  FN USED BY:                                                                 *
*     Update_PNorms, MUNE_U, Expects_By_Store, Quantiles_from_grid &           * 
*     Initialise_P0_V3, EvalMargCDFs                                           *
*******************************************************************************/

void INTEGRATE_V2(char **METHOD, double *lpts, double *cellvol, int *n, int *dim, int *npts,
                    double *lnorm, double *lexpect, int *LOG, double *out){
    CallStackAdd( "INTEGRATE_V2" );
    if( strcmp(*METHOD, "Simpsons_Rule") == 0 ){
        int i, valid;
        i=0;
        valid = TRUE;
        while( (i<*dim) && (valid==TRUE) ){
            if( (n[i] % 2) == 0 ){valid = FALSE;}
            i++;
        }
        if(valid == FALSE){
            Rprintf("State parameter grid is inconsistent with Simpsons_Rule.\n");
            Rprintf("Coverting to Trapezium_Rule.\n");
            strcpy(*METHOD,"Trapezium_Rule");
        }
    }
    
    if(strcmp(*METHOD, "Trapezium_Rule") == 0){
        Trapezium_Rule_V2(lpts, cellvol, n, dim, npts, lnorm, lexpect, LOG, out);
    }
    else if(strcmp(*METHOD, "Simpsons_Rule") == 0){
        Simpsons_Rule_V2(lpts, cellvol, n, dim, npts, lnorm, lexpect, LOG, out);
    }
    else{
        *out = NA_REAL;
        Rprintf("INTEGRATE: Method not recognised!\n");
    }
    CallStackRm( "INTEGRATE_V2" );
}

/* LogLogisticSigmoid **********************************************************
*  INPUT:                                                                      *
*    x = quantile value for which to calculate the actication probability      *
*    loc = location parameter whereby the actication probability is 0.5        *
*    invgrad = inverse gradient evaluated at the location parameter            *
*    calcx = logical argument:                                                 *
*       TRUE - calculate function for all x values for fixed parameters        *
*       FALSE - calculate function at a fixed x for all parameter values       *
*    Log = Logical stating whether the output should be logged                 *
*    nout = number of values to return if(calcx==T){lenght(loc)}else{length(x)}*
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Calculates the activation probability according to a log-logistic         *
*    threshold sigmoid. It can calculate values for varying quantile and fixed *
*    parameters or fixed quantile and varying parameters. The latter case is   *
*    the most common use.                                                      *
* FN USES: None                                                                *
* FN USED BY:                                                                  *
*    THRESHOLD                                                                 *
*******************************************************************************/

void LogLogisticSigmoid( double *x, double *loc, double *invgrad, int *calcx, int *Log, int *nout, double *out)
{
    CallStackAdd( "LogLogisticSigmoid" );
    int i;
    double a, rate;
    
    if(*calcx == 1){
        //Fixed parameters & many points
        for(i=0; i<*nout; i++){
            if( (*loc == 0) && (x[i] == 0) ){
                out[i] = 0.5;
            }
            else if( (*loc == 0) && (*invgrad == 0)){
                out[i] = 0.5;
            }
            else{
                rate = *invgrad/(4 * (*loc));
                a = pow( (x[i])/(*loc), (-1)/(rate) );
                out[i] = pow( 1+a, -1);
            }
        }
    }
    else{
        //many parameters & fixed point
        for(i=0; i<*nout; i++){
            if( (loc[i] == 0) && (*x == 0) ){
                out[i] = 0.5;
            }
            else if( (loc[i] == 0) && (invgrad[i]==0)){
                out[i] = 0.5;
            }
            else{
                rate = invgrad[i] / ( 4 * loc[i] );
                a = pow( (*x)/(loc[i]), (-1)/(rate) );
                out[i] = pow( 1+a, -1);
            }
        }
    }

    //Return the logged values if specified
    if(*Log==1){
        for(i=0; i<*nout; i++){
            out[i] = log( out[i] );
        }
    }
    CallStackRm( "LogLogisticSigmoid" );
}

/* TICKER * ********************************************************************
*  INPUT:                                                                      *
*    now = loop variable                                                       *
*    used = number of "-" that have so far been printed                        *
*    max = loop limit                                                          *
*    U = number of motor units                                                 *
*  OPERATION:                                                                  *
*    Prints to screen a progress bar                                           *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    MUNE_U, SIMULATE_FIRE_VEC                                                 *
*******************************************************************************/

void TICKER( int *now, int *used, int *max, int *U ){
    CallStackAdd( "TICKER" );
    int val, i;
    
    if( *now == -1){
        Rprintf("Units: %d |",*U);
        val = 0;
    }
    else{
        val = (int) ftrunc( (*now) * 25 / (*max) );
        for(i=*used; i<val; i++){
            Rprintf("-");
        }
        if(*now == *max){
            Rprintf("|\n");
        }
    }
    *used = val;
    CallStackRm( "TICKER" );
}

/* Vectorised_KtC **************************************************************
*  INPUT:                                                                      *
*    Cvec = the vectorised covariance matrix (C) for the i^th particle         *
*    K = firing index vector                                                   *
*    u = number of motor units                                                 *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    vectorised calculation of t(K)%*%C                                        *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    Update_Nonbaseline                                                        *
*******************************************************************************/

void Vectorised_KtC(double *Cvec, int *K, int *u, double *out){
    CallStackAdd( "Vectorised_KtC" );
    int i,j,l;
    
    l=0;
    for(i=0;i<*u;i++){
        out[i] = 0;
    }
    
    for(i=0;i<(*u);i++){
        out[i] = out[i] + K[i] * Cvec[l];
        l++;
        for(j=1;j<(*u-i);j++){
            out[i] = out[i] + K[i+j] * Cvec[l];
            out[i+j] = out[i+j] + K[i] * Cvec[l];
            l++;
        }
    }
    CallStackRm( "Vectorised_KtC" );
}

/* Vectorised_KtCK *************************************************************
*  INPUT:                                                                      *
*    C = the vectorised covariance matrix (C) for the i^th particle            *
*    K = firing index vector                                                   *
*    u = number of motor units                                                 *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    vectorised calculation of t(K)%*%C%*%K                                    *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    Update_Nonbaseline, tSIGMA                                                *
*******************************************************************************/

void Vectorised_KtCK(double *C, int *K, int *u, double *out){
    CallStackAdd( "Vectorised_KtCK" );
    int i,j,l;
    
    l=0;
    *out=0;
    for(i=0;i<*u;i++){
        if(K[i]==1){
           *out = *out + C[l];
           for(j=1;j<(*u-i);j++){
               *out = *out + 2*K[i+j]*C[l+j];
           }
        }
        l = l + *u - i;
    }
    CallStackRm( "Vectorised_KtCK" );    
}

/* Update_Baseline *************************************************************
*  INPUT:                                                                      *
*    Zi = Obs. prcess subset of the essential state vector for the ith particle*
*    y = the compund muscle action response                                    *
*  OPERATION:                                                                  *
*    Deterministic update for the observation process' baseline suffucient     *
*    statistics. The result overwrites the values in Zi                        *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    Update_Zobs, Initialise_ZObs_V2                                           *
*******************************************************************************/

void Update_Baseline(double *Zi, double *y){
    CallStackAdd( "Update_Baseline" );
    //Update replaces values in Zi
    
    //Update for b_base
    Zi[3] = Zi[3] + pow(*y - Zi[0],2)/( 2 * ( Zi[1] + 1 ) );
    
    //Update for m_base
    Zi[0] = ((*y)*Zi[1] + Zi[0]) / ( Zi[1] + 1 );
    
    //Update for c_base
    Zi[1] = Zi[1] / ( Zi[1] + 1 );
    
    //Update for a_base
    Zi[2] = Zi[2] + 0.5;
    CallStackRm( "Update_Baseline" );
}

/* Update_Nonbaseline **********************************************************
*  INPUT:                                                                      *
*    Zi = non-baseline subset of the essential state vector for i^th particle  *
*    mb = the baseline 'm' sufficient statistic for the i^th particle          *
*    y = the compund muscle action response                                    *
*    K = firing index vector                                                   *
*    u = number of motor units                                                 *
*  OPERATION:                                                                  *
*    Deterministic update for the i^th particles non-baseline sufficient       *
*    statistics. The values in Zi are replaced with the updated values.        *
*  FN USED:                                                                    *
*     Vectorised_KtCK, Vectorised_KtC                                          *
*  FN USED BY:                                                                 *
*    Initialise_Zi, Update_Zobs, Initialise_ZObs_V2                            *
*******************************************************************************/

void Update_Nonbaseline(double *Zi, double *mb, double *y, int *K, int *u){
    CallStackAdd( "Update_Nonbaseline" );
     //Update replaces values in Zi
    double ktc[*u-1], err, ktck;
    int i, j, l, sumK;
    
    err = *y - *mb;
    sumK = 0;
    for(i=0;i<*u;i++){
        err = err - K[i]*Zi[i];
        sumK = sumK + K[i];        
    }
    
    Vectorised_KtCK( &(Zi[2+*u]), K, u, &ktck);
    Vectorised_KtC( &(Zi[2+*u]), K, u, &(ktc[0]));
    
    l=0;
    for(i=0;i<*u;i++){
        //Update for m vector
        Zi[i] = Zi[i] + ktc[i]*err/(sumK+ktck);
        
        for(j=0;j<(*u-i);j++){
            //update for lower triance (including diag) of C matrix
            Zi[*u + 2 + l] = Zi[*u + 2 + l] - ktc[i]*ktc[i+j]/(sumK+ktck);
            l++;
        }
    }
    
    //Update for b
    Zi[*u+1] = Zi[*u+1] + pow(err,2)/( 2*(sumK+ktck) );
    //Update for a
    Zi[*u] = Zi[*u] + 0.5;
    CallStackRm( "Update_Nonbaseline" );    
}

/* Update_Ph *******************************************************************
*  INPUT:                                                                      *
*    LogP_pts = state parameter posterior on the log scale                     *
*    Prob_pts = P(k=1|PHI) for all PHI in Grid according to threshold function *
*    K_event = 0 or 1, latent of activation event of motor unit                *
*    npts = number of points in the Grid                                       *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Updating procedure for state posterior density accorfding to fire event   *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    Update_P                                                                  *
*******************************************************************************/

void Update_Ph( double *LogP_pts, double *Prob_pts, int *K_event, int *npts, double *out){
    int j;
    CallStackAdd( "Update_Ph" );
    if( *K_event == 1 ){
        for(j=0; j<*npts; j++){
            out[j] = LogP_pts[j] + log(Prob_pts[j]);
        }
    }
    else{
        for(j=0; j<*npts; j++){
            out[j] = LogP_pts[j] + log(1 - Prob_pts[j]);
        }
    }
    CallStackRm( "Update_Ph" );
}

/* Update_P ********************************************************************
*  INPUT:                                                                      *
*    pPI = Structure of Posterior surface information                          *
*    pZst = state process subset of the essential state vector                 *
*    pK = Sampled firing index vectors                                         *
*    pS = administered stimulus                                                *
*    pN = Number of particles                                                  *
*    pU = Number of Motor Units                                                *
*    pG = State parameter Grid                                                 *
*    pGnpts = number of points in the grid                                     *
*    ppFN = Name of the threshold function to use                              *
*    poutK1 = obect to return -> Info for updating Zst when K==1               *
*    poutK0 = obect to return -> Info for updating Zst when K==1               *
*  OPERATION:                                                                  *
*    Wrapper that structures the updating procedure for the state posterior    *
*    densities                                                                 *
*  FN USED:                                                                    *
*     Update_Ph, THRESHOLD, CopyToPost                                         *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                 *
*******************************************************************************/

void Update_P( PostInfo *pPI, int *pZst, int *pK, double *pS, int *pN, int *pU,
                 double *pG, int *pGnpts, char **ppFN, int *poutK1, int *poutK0 ){
    CallStackAdd( "Update_P" );
    int h, i, newh, True, False, max=pPI->nallocated; 
    int NumFire[max], NumNotFire[max], OldInUse[max];
    double *pPtmp, *pFire;
    
    True=TRUE;
    False=FALSE;
    pPtmp = (double *)my_malloc( pPI->GridSize * sizeof(double) );
    pFire = (double *)my_malloc( pPI->GridSize * sizeof(double) );
    
    //Initalise the count vector to zero and copy InUse logicals
    for(h=0;h<max;h++){
        NumFire[h]=0;
        NumNotFire[h]=0;
        OldInUse[h] = pPI->pInUse[h];
    }
    
    //Calculate the count vectors
    for(i=0;i<( (*pU) * (*pN) );i++){
        h = pZst[i];
        if( pK[i] == 1 ){
            NumFire[h]++;
        }
        else{
            NumNotFire[h]++;
        }
    }
    
    //Evaluate Prob of Fire for each value in grid
    THRESHOLD( ppFN, pS, pG, pGnpts, &(False), &(False), &(pPI->GridSize), pFire);
    
    for(h=0;h<max;h++){
        if(OldInUse[h]==TRUE){
            if( NumNotFire[h]>0 ){
                if( NumFire[h]>0 ){
                    //Create New Posterior and update with 1
                    newh = CreateSinglePostInfo( pPI );
                    Update_Ph( pPI->ppPost[h], pFire, &True, &(pPI->GridSize), pPtmp);
                    CopyToPost( pPI, newh, pPtmp );
                    NumFire[h] = newh;
                }
                else{
                    NumFire[h]=NA_REAL;
                }
                //Update existing with 0
                Update_Ph( pPI->ppPost[h], pFire, &False, &(pPI->GridSize), pPtmp);
                CopyToPost( pPI, h, pPtmp );
                NumNotFire[h]=h;
            }
            else{
                NumNotFire[h]=NA_REAL;
                if( NumFire[h]>0 ){
                    //Update existing with 1
                    Update_Ph( pPI->ppPost[h], pFire, &True, &(pPI->GridSize), pPtmp);
                    CopyToPost( pPI, h, pPtmp );
                    NumFire[h]=h;
                }
                else{
                    NumFire[h]=NA_REAL;
                }
            }
        }
        else{
            NumNotFire[h]=NA_REAL;
            NumFire[h]=NA_REAL;
        }
    }
    
    //Export NumNotFire and NumFire
    for(h=0;h<max;h++){
        poutK1[h] = NumFire[h];
        poutK0[h] = NumNotFire[h];
    }
    
    my_free(pPtmp);
    my_free(pFire);
    CallStackRm( "Update_P" );
}

/* Update_PNorms ***************************************************************
*  INPUT:                                                                      *
*    pPI = posterior information structure                                     *
*    ppIntMethod = name of integration method                                  *
*    pGcellvol = cell volume used in Grid                                      *
*    pGn = number of points in each dimension of the grid                      *
*    pGdim = number of dimensiond in grid                                      *
*    pGnpts = overal number of points in grid                                  *
*    pZeroVec = vector of zeros of length pGnpts.                              *
*  OPERATION:                                                                  *
*    re-calculate all of the normalising constant for the poster densities     *
*    that are in use. Value is returned on the log scale.                      *
*  FN USED:                                                                    *
*    INTEGRATE_V2                                                              *
*  FN USEB BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/

void Update_PNorms( PostInfo *pPI, char **ppIntMethod, double *pGcellvol, int *pGn,
                   int *pGdim, int *pGnpts, double *pZeroVec ){
    CallStackAdd( "Update_PNorms" );
    int h, True=TRUE;
    for(h=0;h<(pPI->nallocated);h++){
        if(pPI->pInUse[h] == TRUE){
            pPI->pNorm[h] = 0;
            INTEGRATE_V2( ppIntMethod, pPI->ppPost[h], pGcellvol, pGn, pGdim,
                pGnpts, pZeroVec, pZeroVec, &True, &(pPI->pNorm[h]));
        }
    }
    CallStackRm( "Update_PNorms" );
}

/* Update_Zobs *****************************************************************
*  INPUT:                                                                      *
*    y = compound muscle action reponse                                        *
*    Zobs = observation process subset of the essential state vector           *
*    K = (sampled) firing index vector                                         *
*    N = number of particles                                                   *
*    u = number of motor units                                                 *
*    dzobs = length of Zobs for a single particle                              *
*  OPERATION:                                                                  *
*    Wrapper for the updating procedure of the observation process' sufficient *
*    statistics.                                                               *
*  FN USED:                                                                    *
*    Update_Baseline, Update_Nonbaseline                                       *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/

void Update_Zobs(double *y, double *Zobs, int *K, int *N, int *u, int *dzobs){
    CallStackAdd( "Update_Zobs" );
    int i, j, startz, startk, base;
    
    startz = 0;
    startk = 0;
    for(i=0;i<*N;i++){
        
        //Status of vector K
        base = 1;
        j=0;
        while( (base == 1) && (j<*u) ){
            if(K[startk+j] == 1){
                base = 0;
            }
            j++;
        }
        
        //Update given K
        if(base==1){
            Update_Baseline( &(Zobs[startz]) , y );
        }
        else{
            Update_Nonbaseline( &(Zobs[startz+4]), &(Zobs[startz]), y, &(K[startk]), u );
        }
        
        //iterate start arguments
        startz = startz + (*dzobs);
        startk = startk + (*u);
        
    }
    CallStackRm( "Update_Zobs" );
}

/* Update_Zst ******************************************************************
*  INPUT:                                                                      *
*    pZst = state process subset of the essential state vector                 *
*    pK = (sampled) firing index vector                                        *
*    pLabK0 = Relabeling values when k==0                                      *
*    pLabK1 = Relabeling values when k==1                                      *
*    pU = number of motor units                                                *
*    pN = number of particles                                                  *
*  OPERATION:                                                                  *
*    Updates the labels that links the particles to the point evaluated state  *
*    posteriors                                                                *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                 *
*******************************************************************************/

void Update_Zst( int *pZst, int *pK, int *pLabK0, int *pLabK1, int *pU, int *pN ){
    CallStackAdd( "Update_Zst" );
    int i, h;
    for(i=0;i<((*pU) * (*pN));i++){
        h = pZst[i];
        if( pK[i] == 0 ){
            pZst[i] = pLabK0[h];
        }
        else{  //pK[i]==1
            pZst[i] = pLabK1[h];
        }
    }
    CallStackRm( "Update_Zst" );
}

/* Initialise_P_V2 *************************************************************
*  INPUT:                                                                      *
*    grid = A grid that discretizes the state parameter space                  *
*    n = number of points in each dimension of Grid                            *
*    dim = number of dimensions in Grid                                        *
*    alpha = The alpha parameters for the 'dim'-dimensional scaled Beta prior  *
*    beta = The beta parameters for the 'dim'-dimensional scaled Beta prior    *
*    LOG = Logical vector stating whether the retuned values should be logged  *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Calculates the prior density approximation for the state parameters on the*
*    grid support. Assumes each parameter is independent. Prior:               *
*      PHI ~ MultiV-Scaled-Beta( alpha, beta, range = grid boundaries )        *
*  FN USED: None                                                               *
*  FN USED BY:                                                                 *
*    Initialise_P0_V2                                                           *
*******************************************************************************/

void Initialise_P_V2( double *grid, int *n, int *dim, double *alpha, double *beta, int *LOG, double *out)
{
     CallStackAdd( "Initialise_P_V2" );
     int i, d;
     double scaled_pt;
     
     i=0;
     while( i < *n ){
        out[i] = 0;
        for(d=0;d<*dim;d++){
            scaled_pt = (grid[d*(*n) + i] - grid[(d+1)*(*n) -1]) / (grid[d*(*n)] - grid[(d+1)*(*n) -1]);
            out[i] += dbeta( scaled_pt, alpha[d], beta[d], 1);
        }
        if(*LOG == 0){
            out[i] = exp(out[i]);
        }
        i++;
     }
     CallStackRm( "Initialise_P_V2" );
}

/* Initialise_P0_V3 ************************************************************
*  INPUT:                                                                      *
*    pSb = vector of baseline stimuli                                          *
*    pSmax = a single supramaximal stimulus                                    *
*    pnb = number of baseline observations                                     *
*    pG = A grid that discretizes the state parameter space                    *
*    pGdim = number of dimensions in Grid                                      *
*    pGnpts = number of points in the Grid                                     *
*    pGcellvol = Grid cell volume                                              *
*    pAlpha = The alpha parameters for the 'dim'-dimensional scaled Beta prior *
*    pBeta = The beta parameters for the 'dim'-dimensional scaled Beta prior   *
*    ppFN = name of Threshold function                                         *
*    ppMETHOD = name of integration method                                     *
*    pLOG = Logical vector stating whether the retuned values should be logged *
*    pMargPart = To return ML ests. for st. proc contribution of calib. data   *
*    pout = object to return                                                   *
*  OPERATION:                                                                  *
*    Initialise the posterior approximation to the state parameter that        *
*    accounts for the inital data set consisting of nb baseline observations   *
*    and a single supermaximal response. This command also evaluates the       *
*    marginal contribution for the calibration data from the state process.    *
*  FN USED:                                                                    *
*    Initalise_P_V2, THRESHOLD, INTEGRATE_V2                                   *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/
        
void Initialise_P0_V3(double *pSb, double *pSmax, int *pnb, double *pG, int *pGdim,
        int *pGnpts, double *pGcellvol, int *pGn, double *pAlpha, double *pBeta, char **ppFN,
        char **ppMETHOD, int *pLOG, int *pU, double *pMargPart, double *pout){

    CallStackAdd( "Initialise_P0_V3" );
    int i, j, False, True;
    double *pLogPstar, *ptmp, *pZeroVec, lNorm, pfire;
    
    False = 0;
    True = 1;
    
    pLogPstar = (double*) my_malloc( (*pGnpts) * sizeof(double) );
    ptmp = (double*) my_malloc( (*pGnpts) * sizeof(double) );
    pZeroVec = (double *)my_malloc( (*pGnpts) * sizeof(double) );
    for(i=0;i<*pGnpts;i++){pZeroVec[i]=0;}
    Initialise_P_V2( pG, pGnpts, pGdim, pAlpha, pBeta, &True, pLogPstar);
    INTEGRATE_V2( ppMETHOD, pLogPstar, pGcellvol, pGn, pGdim, pGnpts,
        pZeroVec, pZeroVec, &True, &lNorm );           

    for(i=0; i < *pnb; i++){
        THRESHOLD( ppFN, &(pSb[i]), pG, pGnpts, &False, &True, pGnpts, ptmp);
        INTEGRATE_V2( ppMETHOD, pLogPstar, pGcellvol, pGn, pGdim, pGnpts,
            &lNorm, ptmp, &False, &pfire );
        pMargPart[i] = ((*pU) * log(1-pfire));
        for(j=0; j<*pGnpts ;j++){
            pLogPstar[j] += log(1 - exp(ptmp[j]));
        }
        INTEGRATE_V2( ppMETHOD, pLogPstar, pGcellvol, pGn, pGdim, pGnpts,
            pZeroVec, pZeroVec, &True, &lNorm );           
    }

    THRESHOLD( ppFN, pSmax, pG, pGnpts, &False, &True, pGnpts, ptmp);
    INTEGRATE_V2( ppMETHOD, pLogPstar, pGcellvol, pGn, pGdim, pGnpts,
        &lNorm, ptmp, &True, &pfire );
    pMargPart[ *pnb ] = ((*pU) * pfire);
    for(j=0; j<*pGnpts; j++){
        pout[j] = pLogPstar[j] + ptmp[j];
        if(*pLOG == False){
           pout[j] = exp(pout[j]);
        }
    }
    my_free( ptmp );
    my_free( pLogPstar );
    my_free( pZeroVec );
    CallStackRm( "Initialise_P0_V3" );
}

/* Make_Regular_Grid ***********************************************************
*  INPUT:                                                                      *
*    n = number of points in each dimension of Grid                            *
*    dim = number of dimensions in Grid                                        *
*    nopts = n * dim                                                           *
*    lower = vector of lower bounds for each dimension                         *
*    upper = vector of upper bounds for each dimension                         *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Evaluates a discretised grid for the state parameter space                *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    MUNE_U, Quantiles_from_grid, InitialiseMargInfo                           *
*******************************************************************************/

void Make_Regular_Grid(int *n, int *dim, int *nopts, double *lower, double *upper, double *out)
{
    CallStackAdd( "Make_Regular_Grid" );
    int pt, d, step[*dim], itter[*dim];
    double h[*dim];
    
    for(d=0; d < *dim; d++){
      h[d] = (upper[d] - lower[d]) / (n[d] - 1);
      itter[d] = 0;
      if(d==0){
          step[d] = 0;
      }else{
          step[d] = step[d-1] + *nopts;
      }
    }
        
    for(pt=0; pt < *nopts; pt++){
        for(d=0; d < *dim; d++){
            out[step[d]+pt] = lower[d] + itter[d]*h[d];
        }
        itter[0]++;
        for(d=0; d < *dim; d++){
            if( (itter[d] == n[d]) && (d != *dim) ){
                itter[d+1]++;
                itter[d] = 0;
            }
        }
    }
    CallStackRm( "Make_Regular_Grid" );
}

/* Initialise_ZObs_V2 **********************************************************
*  INPUT:                                                                      *
*    pYbase = baseline responses                                               *
*    pYmax = supramaximal stimulus response                                    *
*    pnb = number of baseline responses                                        *
*    pZstar  = initial values for ESV {mb,cb,ab,bb,m,v,a,b}                    *
*    pU = number of motor units                                                *
*    pN = number of particles                                                  *
*    pdzi = length of Obs. process subest of ZObs for a single particle        *
*    pMargPart = To return ML ests. for obs. proc contribution of calib. data  *
*    pout = object to return for ESV                                           *
*  OPERATION:                                                                  *
*    Initialises the observation process subset of the essential state vector  *
*    such that it accounts for the initial data set and evaluate its           *
*    contribution to the marginal likelibood estimate                          *
*  FN USED:                                                                    *
*    dnonstdt, Update_Baseline, Update_Nonbaseline, tMU, tSIGMA, tDF           *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/

void Initialise_ZObs_V2(double *pYbase, double *pYmax, int *pnb, double *pZstar, 
                    double *pbinfo, int *pU, int *pN, int *pdzi, double *pMargPart,
                    double *pout, double *pb0, double *phatnub ){

    CallStackAdd( "Initialise_ZObs_V2" );
    int i, j, start, t, TRUE, FALSE, allfire[*pU], alllatent[*pU];
    double Zi[*pdzi], sig, mean, df, h;
    TRUE = 1;
    FALSE = 0;
    for(j=0;j<4;j++){
        Zi[j]=pZstar[j];
    }
    Zi[4+*pU] = pZstar[6];
    Zi[5+*pU] = pZstar[7];
    start = 6+*pU;
    for(j=0;j<*pU;j++){
        Zi[4+j] = pZstar[4];
        allfire[j] = 1;
        alllatent[j] = 0;
        for(i=j;i<*pU;i++){
            if(i==j){
                Zi[start] = pZstar[5];
            }
            else{
                Zi[start] = 0.0;
            }
            start++;
        }
    }
    
    for(t=0;t<*pnb;t++){
        tMU( &(Zi[0]), &(alllatent[0]), pU, &TRUE, &mean);
        tSIGMA( &(Zi[0]), &(alllatent[0]), pU, &TRUE, &sig);
        tDF( &(Zi[0]), pU, &TRUE, &df);
        dnonstdt(&(pYbase[t]), &mean, &sig , &df, &TRUE, &(pMargPart[t]) );
        Update_Baseline( &(Zi[0]), &(pYbase[t]) );
    }
    
    //Determine the b statistic
    h = 1/qgamma( 0.5, Zi[2], 1/Zi[3], TRUE, FALSE );
    Zi[5+*pU] = qgamma( pbinfo[0], Zi[4+*pU], h, TRUE, FALSE ) / pbinfo[1];
    *phatnub = h;
    *pb0 = Zi[5+*pU];
        
    tMU( &(Zi[0]), &(allfire[0]), pU, &FALSE, &mean);
    tSIGMA( &(Zi[0]), &(allfire[0]), pU, &FALSE, &sig);
    tDF( &(Zi[0]), pU, &FALSE, &df);
    dnonstdt( pYmax, &mean, &sig , &df, &TRUE, &(pMargPart[ *pnb ]) );
    Update_Nonbaseline( &(Zi[4]), &(Zi[0]), pYmax, &(allfire[0]), pU );

    start=0;
    for(i=0;i<*pN;i++){
        for(j=0;j<*pdzi;j++){
            pout[start+j] = Zi[j];
        }
        start = start + *pdzi;
    }
    
    CallStackRm( "Initialise_ZObs_V2" );
}

/* Initialise_ZSt ***************************************************************
*  INPUT:                                                                      *
*    h = the value to initialise with                                          *
*    u = number of motor units                                                 *
*    N = number of particles                                                   *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Initialises the state process subset of the essential state vector to the *
*    label for all motor units and particles                                   *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                 *
*******************************************************************************/

void Initialise_ZSt( int *h, int *u, int *N, int *out){
    CallStackAdd( "Initialise_ZSt" );
    int i;
    for(i=0;i<((*u) * (*N));i++){
        out[i] = *h;
    }
    CallStackRm( "Initialise_ZSt" );
}

/* dnonstdt ********************************************************************
*  INPUT:                                                                      *
*     x = point at which to evaluate function                                  *
*     mu = Location parameter                                                  *
*     sigma = scale parameter                                                  *
*     df = degrees of freedom                                                  *
*     LOG = logical stating whether the density value should be logged         *
*     out = density value to return                                            *
*  OPERATION:                                                                  *
*     Calculates the density value for the non-standardised student's t        *
*     distribution ( X ~ t(mu, sigma, df) )                                    *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    Predictive_ObsProcess_ij, Initialise_ZObs_V2                              *
*******************************************************************************/

void dnonstdt(double *x, double *mu, double *sigma, double *df, int *LOG, double *out){
    CallStackAdd( "dnonstdt" );
    double tmp;
    
    tmp = (*x - *mu)/(*sigma);
    
    if(*LOG == FALSE){
        *out = dt(tmp, *df, *LOG);
        *out = *out / *sigma;
    }
    else if(*LOG == TRUE){
        *out = dt(tmp, *df, *LOG);
        *out = *out - log(*sigma);
    }
    else{
        *out = NA_REAL;
        Rprintf("Error in dnonstdt function: 'log' is not logical!\n");
    }
    CallStackRm( "dnonstdt" );
}

/* Marginalise_K ***************************************************************
*  INPUT:                                                                      *
*    probs = Joint predictive probabilities P(y_{t},k_{t}|Z_{t-1}^{(i)})       *
*    kdim = size of firing index vector (K) space (kdim = 2^U)                 *
*    N = Number of particle                                                    *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Calculates the predictive probability for each particle by marginalising  *
*    over the firing index vector: i.e.                                        *
* P(y_{t}|Z_{t-1}^{(i)}) = \sum_{k_{t} \in K_{t}} P(y_{t},k_{t}|Z_{t-1}^{(i)}) *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/

void Marginalise_K( double *probs, int *kdim, int *N, double *out ){
    CallStackAdd( "Marginalise_K" );
    int i, j, start;
    for(i=0;i<*N;i++){
        out[i] = 0;
        start = i * (*kdim);
        for(j=0;j<*kdim;j++){
            out[i] = out[i] + probs[start+j];
        }
    }
    CallStackRm( "Marginalise_K" );
}

/* Pred_Kvec_ij ****************************************************************
*  INPUT:                                                                      *
*    probs1 = vector of P(x=1|s,Z)                                             *
*    probs0 = vector of P(x=1|s,Z)                                             *
*    Zsti = state process subset of the essential state process for particle i *
*    Kj = firing index vector                                                  *
*    u = number of motor units                                                 *
*    LOG = logical stating whether the output should be logged                 *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Calculates the predictive probability for the j^th firing index vector    *
*    event for the i^th particle                                               *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    Pred_yt_i                                                                 *
*******************************************************************************/

void Pred_Kvec_ij( double *probs1, double *probs0, int *Zsti, int *Kj, int *u, int *LOG, double *out){
    CallStackAdd( "Pred_Kvec_ij" );
    int d, h;
    double vecprob;
    vecprob = 1;
    for(d=0;d<*u;d++){
        h = Zsti[d];
        if(Kj[d]==0){
            vecprob = vecprob * probs0[h];
        }
        else{
            vecprob = vecprob * probs1[h];
        }
    }
    if(*LOG == TRUE){
        *out = log(vecprob);
    }
    else if(*LOG == FALSE){
        *out = vecprob;
    }
    else{
        *out = NA_REAL;
        Rprintf("Pred_Kvec_ij: 'log' is not logical!\n");
    }
    CallStackRm( "Pred_Kvec_ij" );
}

/* tMU *************************************************************************
*  INPUT:                                                                      *
*    Zi = Obs. prcess subset of the essential state vector for the ith particle*
*    K = firing index vector                                                   *
*    u = Number of motor units                                                 *
*    BASELINE = Logical, stating whether to extract the baseline elements      *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Extracts the relevant information from Zi and calulates the location      *
*    parameter for the non-statndatd t distribution                            *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    Predictive_ObsProcess_ij, Initialise_ZObs_V2                              *
*******************************************************************************/

void tMU(double *Zi, int *K, int *u, int *BASELINE, double *out){
    CallStackAdd( "tMU" );
    int i;
    
    if(*BASELINE == FALSE){
        *out=Zi[0];
        for(i=0;i<*u;i++){
            *out = *out + K[i]*Zi[4+i];
        }
    }
    else if(*BASELINE == TRUE){
        *out=Zi[0];
    }
    else{
        *out = NA_REAL;
        Rprintf("Error in tMU function: 'BASELINE' is not logical!\n");    
    }
    CallStackRm( "tMU" );
}

/* tSIGMA **********************************************************************
*  INPUT:                                                                      *
*    Zi = Obs. prcess subset of the essential state vector for the ith particle*
*    K = firing index vector                                                   *
*    u = Number of motor units                                                 *
*    BASELINE = Logical, stating whether to extract the baseline elements      *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Extracts the relevant information from Zi and calulates the scale         *
*    parameter for the non-statndatd t distribution                            *
*  FN USED:                                                                    *
*     Vectorised_KtCK                                                          *
*  FN USED BY:                                                                 *
*    Predictive_ObsProcess_ij, Initialise_ZObs_V2                              *
*******************************************************************************/

void tSIGMA(double *Zi, int *K, int *u, int *BASELINE, double *out){
    CallStackAdd( "tSIGMA" );
    double sigsq, ktck;
    int sumk, i;
    
    if(*BASELINE == FALSE){
        sumk = 0;
        for(i=0;i<*u;i++){
            sumk = sumk + K[i];
        }
        Vectorised_KtCK( &(Zi[6+*u]), K, u, &ktck);
        sigsq = Zi[5+*u] * ( ((double)sumk) + ktck) / Zi[*u+4];
        *out = sqrt(sigsq);
    }
    else if(*BASELINE == TRUE){
        sigsq = Zi[3] * (1 + Zi[1]) / Zi[2];
        *out = sqrt(sigsq);
    }
    else{
        *out = NA_REAL;
        Rprintf("Error in tSIGMA function: 'BASELINE' is not logical!\n");
    }
    CallStackRm( "tSIGMA" );
}

/* tDF *************************************************************************
*  INPUT:                                                                      *
*    Zi = Obs. prcess subset of the essential state vector for the ith particle*
*    u = Number of motor units                                                 *
*    BASELINE = Logical, stating whether to extract the baseline elements      *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Extracts the relevant information from Zi and calulates the degree of     *
*    freedom for the non-statndatd t distribution                              *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    Predictive_ObsProcess_ij, Initialise_ZObs_V2                              *
*******************************************************************************/

void tDF(double *Zi, int *u, int *BASELINE, double *out){
    CallStackAdd( "tDF" );
    if(*BASELINE == FALSE){
        *out = 2*Zi[*u+4];
    }
    else if(*BASELINE == TRUE){
        *out = 2*Zi[2];
    }
    else{
        *out = NA_REAL;
        Rprintf("Error in tDF function: 'BASELINE' is not logical!\n");    
    }
    CallStackRm( "tDF" );
}

/* Predictive_ObsProcess_ij ****************************************************
*  INPUT:                                                                      *
*    Zi = obs. process subset of the essential state vector for particle i     *
*    y = the compund muscle action response                                    *
*    K = firing index vector                                                   *
*    u = number of motor units                                                 *
*    LOG = logical stating whether the output should be logged                 *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Calculates P(y_{t}|k_{t},Z_{t-1}^{(i)})                                   *
*  FN USED:                                                                    *
*    tMU, tSIGMA, tDF, dnonstdt                                                *
*  FN USED BY:                                                                 *
*    Pred_yt_i                                                                 *
*******************************************************************************/

void Predictive_ObsProcess_ij(double *Zi, double *y, int *K, int *u, int *LOG, double *out){
    CallStackAdd( "Predictive_ObsProcess_ij" );
    double mu, sigma, df;
    int BL, i;
    
    BL = TRUE;
    i=0;
    while( (BL==TRUE) && (i<*u) ){
        if( K[i] == 1 ){
            BL = FALSE;
        }
        i++;
    }
    
    tMU(Zi, K, u, &BL, &mu);
    tSIGMA(Zi, K, u, &BL, &sigma);
    tDF(Zi, u, &BL, &df);
    if( (mu==NA_REAL) || (sigma==NA_REAL) || (df==NA_REAL) ){
        *out = NA_REAL;
        Rprintf("Error in calculating Predictive_ObsProcess_i!");
    }
    else{
        dnonstdt(y, &mu, &sigma, &df, LOG, out);
    }
    CallStackRm( "Predictive_ObsProcess_ij" );        
}

/* Pred_Yt_i *******************************************************************
*  INPUT:                                                                      *
*    y = the compund muscle action response                                    *
*    Zobsi = obs. process subset of the essential state vector for particle i  *
*    Zsti = state process subset of the essential state vector for particle i  *
*    probs1 = vector of P(x=1|s,Z)                                             *
*    probs0 = vector of P(x=1|s,Z)                                             *
*    u = number of motor units                                                 *
*    kdim = size of the fireing index vector space (kdim = 2^u)                *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Calculates P(y_{t},k_{t}|Z_{t-1}^{(i)})                                   *
*  FN USED:                                                                    *
*    Predictive_ObsProcess_ij, Pred_Kvec_ij                                    *
*  FN USED BY:                                                                 *
*    Pred_Yt                                                                   *
*******************************************************************************/

void Pred_Yt_i(double *y, double *Zobsi, int *Zsti, double *probs1, double *probs0, int *u,
                    int *kdim, double *out){
    CallStackAdd( "Pred_Yt_i" );
    int j,d,K[*u], True;
    double LPY_KZ_ij, LPK_Z_ij; 
    
    True=1;
    for(d=0;d<*u;d++){
        K[d]=0;
    }
    
    for(j=0;j<*kdim;j++){
        Predictive_ObsProcess_ij(Zobsi, y, &(K[0]), u, &True, &LPY_KZ_ij);
        Pred_Kvec_ij(probs1, probs0, Zsti, &(K[0]), u, &True, &LPK_Z_ij);
        out[j] = exp(LPY_KZ_ij + LPK_Z_ij);
        
        K[0]++;
        for(d=0;d<(*u-1);d++){
            if(K[d]==2){
                K[d]=0;
                K[d+1]++;
            }
        }
    }
    CallStackRm( "Pred_Yt_i" );
}

/* Pred_Yt *********************************************************************
*  INPUT:                                                                      *
*    y = the compund muscle action response                                    *
*    Zobs = observation process subset of the essential state vector           *
*    Zst = state process subset of the essential state vector                  *
*    probs1 = vector of P(x=1|s,Z)                                             *
*    probs0 = vector of P(x=1|s,Z)                                             *
*    u = number of motor units                                                 *
*    kdim = size of the fireing index vector space (kdim = 2^u)                *
*    nZobsi = number of values that define Zobs for a single particle          *
*    N = number of particles                                                   *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Performs the Pred_Yt_i function on all particles                          *
*  FN USED:                                                                    *
*    Pred_Yt_i                                                                 *
* FN USED BY:                                                                  *
*    MUNE_U                                                                    *
*******************************************************************************/

void Pred_Yt(double *y, double *Zobs, int *Zst, double *probs1, double *probs0, int *u,
                    int *kdim, int *nZobsi, int *N, double *out){
    CallStackAdd( "Pred_Yt" );
    int i, start1, start2, start3;
    
    for(i=0;i<*N;i++){
        start1 = i * (*nZobsi);
        start2 = i * (*u);
        start3 = i * (*kdim);
        Pred_Yt_i(y, &(Zobs[start1]), &(Zst[start2]), probs1, probs0, u, kdim, &(out[start3]));
    }
    CallStackRm( "Pred_Yt" );
}

/* Prob_Fire_V2 ****************************************************************
*  INPUT:                                                                      *
*    S = administered stimulus                                                 *
*    pPI = pointer to state posterior information structure                    *
*    METHOD = name of integration method                                       *
*    ppFN = name of threshold function                                         *
*    Grid = points in state parameter space where P_lvals are evaluated for    *
*    cellvol = cell volume used in Grid                                        *
*    n = number of points in each dimension of Grid                            *
*    dim = number of dimensions in Grid                                        *
*    npts = n * dim                                                            *
*    out0 = object to return for x=0                                           *
*    out1 = object to return for x=1                                           *
*  OPERATION:                                                                  *
*    Calculates the probability of firing for each state parameter posterior   *
*    approximation by calculating the expectation: E_{PHI|Z}[ P(x| S PHI) ]    *
*  FN USED:                                                                    *
*    INTEGRATE_V2, THRESHOLD                                                   *
* FN USED BY:                                                                  *
*    MUNE_U                                                                    *
*******************************************************************************/

void Prob_Fire_V2(double *S, PostInfo *pPI, char **METHOD, char **ppFN, double *Grid, 
                  double *cellvol, int *n, int *dim, int *npts, double *out0, double *out1){
    CallStackAdd( "Prob_Fire_V2" );
    int True, False, h;
    double *lexpect0, *lexpect1, total;
    False = 0;
    True = 1;
    lexpect0 = (double*) my_malloc( (*npts) * sizeof(double) );
    lexpect1 = (double*) my_malloc( (*npts) * sizeof(double) );

    THRESHOLD( ppFN, S, Grid, npts, &False, &True, npts, lexpect1);
    for(h=0;h<*npts;h++){
        lexpect0[h] = log(1-exp(lexpect1[h]));
    }
    for(h=0;h<(pPI->nallocated);h++){
        if(pPI->pInUse[h]==TRUE){
            INTEGRATE_V2(METHOD, pPI->ppPost[h], cellvol, n, dim, npts,
                           &(pPI->pNorm[h]), lexpect1, &False, &(out1[h]));
            INTEGRATE_V2(METHOD, pPI->ppPost[h], cellvol, n, dim, npts,
                           &(pPI->pNorm[h]), lexpect0, &False, &(out0[h]));
            total = out1[h] + out0[h];
            out1[h] = out1[h] / total;
            out0[h] = out0[h] / total;
        }
        else if(pPI->pInUse[h]==FALSE){
            out0[h] = 0.0;
            out1[h] = 0.0;
        }
        else{
            out0[h] = NA_REAL;
            out1[h] = NA_REAL;
            Rprintf("Prob_Fire: Invalid value for InUse!");
        }
    }
    my_free(lexpect1);
    my_free(lexpect0);
    CallStackRm( "Prob_Fire_V2" );
}

/* Expects_By_Store ************************************************************
*  INPUT:                                                                      *
*    pPI = Posterior intformation structure                                    *
*    pG = A grid that discretizes the state parameter space                    *
*    pParam = Indicates which state parameter to evaluate (if =pGdim, then all)*
*    pOrder = Which moment to evaluate                                         *
*    ppMETHOD = the integration method to perform                              *
*    pGcellvol = cell volume used in Grid                                      *
*    pGn = number of points in each dimension of Grid                          *
*    pGdim = number of dimensions in Grid                                      *
*    pGnpts = overall number of points in grid                                 *
*    pout = object to return                                                   *
*  OPERATION:                                                                  *
*    Calculates the expectation E[PHI{d}^ord|Z_{h}] for the spcified state     *
*    parameter index by d and active posterior surfaces                        *
*  FN USED:                                                                    *
*     INTEGRATE_V2                                                             *
* FN USED BY:                                                                  *
*    MUNE_U, Summary_Zst                                                       *
*******************************************************************************/

void Expects_By_Store( PostInfo *pPI, double *pG, int *pParam, double *pOrder, 
                       char **ppMETHOD, double *pGcellvol, int *pGn, int *pGdim,
                       int *pGnpts, double *pout ){
    CallStackAdd( "Expects_By_Store" );
    int d, i, nout, start_param, start_out, False=FALSE ;
    double *plexpect;
    if(*pParam == *pGdim){ //If all parameter expectations to be calculated (SUMMARY)
        nout = *pGdim;
        plexpect = (double*) my_malloc( nout * (*pGnpts) * sizeof(double) );
        start_param = 0;
        for(d=0;d<nout;d++){
            for(i=0;i<*pGnpts;i++){
                plexpect[start_param + i] = (*pOrder) * log( pG[start_param+i] );
            }
            start_param += (*pGnpts);
        }
    }
    else{  //If expectation for a single parameter is required (reordering motor units)
        nout = 1;
        plexpect = (double*) my_malloc( nout * (*pGnpts) * sizeof(double) );
        start_param = (*pParam) * (*pGnpts);
        for(i=0;i<*pGnpts;i++){
            plexpect[start_param + i] = (*pOrder) * log( pG[start_param+i] );
        }
    }
        
    //Set output vector to zero
    for(i=0;i<(pPI->nallocated * nout);i++){
        pout[i] = 0;
    }
    
    //Calculate expectations
    start_out=0;
    for(i=0;i<pPI->nallocated;i++){
        if(pPI->pInUse[i]==TRUE){
            start_param = 0;
            for(d=0;d<nout;d++){
                INTEGRATE_V2( ppMETHOD, pPI->ppPost[i], pGcellvol, pGn, pGdim, pGnpts,
                    &(pPI->pNorm[i]), &(plexpect[start_param]), &False, &(pout[start_out+d]));
                start_param += *pGnpts;
            }
        }
        start_out +=nout;
    }
    my_free(plexpect);
    CallStackRm( "Expects_By_Store" );
}

/* ORDER ***********************************************************************
*  INPUT:                                                                      *
*    Expects = The expectations for which to order the motor units             *
*    Zst = the state process subset of the essential state vector (lables)     *
*    U = Number of motor units                                                 *
*    N = Number of particles                                                   *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Systematicaly orders the motor units within each particle according to the*
*    expected value for a desired state parameter. This function returns, for  *
*    each particle, a vector containing a position label for which to reorder  *
*    the motor units.                                                          * 
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/

void ORDER( double *Expects, int *Zst, int *U, int *N, int *out){
    CallStackAdd( "ORDER" );
    int i, j, ord[*U], start_i, ind, tmpi, count;
    double tmpd, exps[*U];
    
    start_i = 0;
    for(i=0;i<*N;i++){
        
        for(j=0;j<*U;j++){
            ord[j] = j;
            ind = Zst[ start_i + j ];
            exps[j] = Expects[ ind ];
        }
        
        count = 1;
        while(count != 0){
            count = 0;
            for(j=0;j<(*U-1);j++){
                if(exps[j]>exps[j+1]){   //Bubble sort ordering!!!
                    tmpd = exps[j];
                    exps[j] = exps[j+1];
                    exps[j+1] = tmpd;
                    tmpi = ord[j];
                    ord[j] = ord[j+1];
                    ord[j+1] = tmpi;
                    count++;
                }
            }
        }
        
        for(j=0;j<*U;j++){
            out[ start_i + j ] = ord[j];
        }

        start_i = start_i + *U;
    }
    CallStackRm( "ORDER" );
}

/* Sym_Mat_Inds ****************************************************************
*  INPUT:                                                                      *
*    U = Number of motor units                                                 *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Creates a function throught the use of indicators that maps the vectorised*
*    covariance matrix C (that has repeared terms removed) to the correct order*
*    that fills a symmetric square matrix.                                     *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    ORDER_Zobs                                                                *
*******************************************************************************/

void Sym_Mat_Inds( int *U, int *out ){
    CallStackAdd( "Sym_Mat_Inds" );
    int i, j, a, b, c;
    
    a=0;
    b=0;
    for(i=0;i<*U;i++){
        for(j=0;j<*U;j++){
            if( i<=j ){
                 out[ b + j] = a;
                 a++;
            }
            else{
                c = j * (*U);
                out[ b + j ] = out[ c + i ];
            }
        }
        b = b + *U;
    }
    CallStackRm( "Sym_Mat_Inds" );
}

/* ORDER_C_IND *****************************************************************
*  INPUT:                                                                      *
*    ORD = vector containing the reordering labels for a paricular particle    *
*    IND = vector of labels that maps the unique covariance matrix (C) values  *
*             from a vector to a symmetric matrix                              *
*    U = Number of motor units                                                 *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Reorders the covariance matrix sufficient statistic according to ORD. This*
*    is performed by reordering the IND vector and returning the revevant      *
*    values for the matrix's lower triange with the diagonal elements.         *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    ORDER_Zobs                                                                *
*******************************************************************************/

void ORDER_C_IND( int *ORD, int *IND, int *U, int *out ){
    CallStackAdd( "ORDER_C_IND" );
    int i, j, a, b, c;
    
    a=0;
    for(i=0;i<*U;i++){
        b = ORD[i] * (*U);
        for(j=i;j<*U;j++){
            c = b + ORD[j];
            out[a] = IND[ c ];
            a++;
        }
    }    
    CallStackRm( "ORDER_C_IND" );
}

/* ORDER_Zobs ******************************************************************
*  INPUT:                                                                      *
*    Z = observation process subset of the essential state vector              *
*    Ords = labels for which to reorder the essential state vector             *
*    U = Number of motor units                                                 *
*    N = Number of particles                                                   *
*    dZ = Number of sufficient statictical values in Zobs for a single particle*
*  OPERATION:                                                                  *
*    Reorders the information for each particle's essential state vector       *
*    according to the associated order defined within Ords. The reorded        *
*    essential state vectors are returned by over writing the existing data in *
*    Z                                                                         *
*  FN USED:                                                                    *
*    Sym_Mat_Inds, ORDER_C_IND                                                 *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/

void ORDER_Zobs( double *Z, int *Ords, int *U, int *N, int *dZ){
     CallStackAdd( "ORDER_Zobs" );
     int i, j, lenCvec, *MatInd, *indC, start0, start1, start2, start3, place;
     double *tmpM, *tmpC;
     
     lenCvec = *dZ - *U - 6; 
     tmpC = (double*) my_malloc( lenCvec * sizeof(double) );
     indC = (int*) my_malloc( lenCvec * sizeof(int) );
     tmpM = (double*) my_malloc( (*U) * sizeof(double) );
     MatInd = (int*) my_malloc( (*U) * (*U) * sizeof(int) );
     
     Sym_Mat_Inds( U, MatInd );

     start1 = 0;  //Start of Zi
     start0 = 0;   //Start of ordi
     for(i=0;i<*N;i++){
         
         start2 = start1 + *U + 6; //Start of Ci
         start3 = start1 + 4;      //Start of Mi
         //copy M and C data into tempory vectord
         for(j=0;j<lenCvec;j++){
             tmpC[j] = Z[ start2 + j];
             if(j<*U){
                 tmpM[j] = Z[start3 + j];
             }
         }
         
         /*Calc reorder for C*/
         ORDER_C_IND( &(Ords[start0]), MatInd, U, indC );
         
         /*Replace M and C values according to order*/
         for(j=0;j<lenCvec;j++){
             place = indC[j];
             Z[ start2 + j] = tmpC[ place ];
             if(j<*U){
                 place = Ords[ start0 + j];
                 Z[ start3 + j] = tmpM[ place ];
             }
         }
         
         start0 = start0 + *U;
         start1 = start1 + *dZ;
     }
     
     my_free(tmpC);
     my_free(tmpM);
     my_free(indC);
     my_free(MatInd);
     CallStackRm( "ORDER_Zobs" );
}

/* ORDER_ZST *******************************************************************
*  INPUT:                                                                      *
*    Zst = state process subset of the essential state vector (lables)         *
*    ORD = labels for which to reorder the essential state vector              *
*    U = Number of motor units                                                 *
*    N = Number of particles                                                   *
*  OPERATION:                                                                  *
*    Reorders Zst according to ORD                                             *
*  FN USED: None                                                                    *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/

void ORDER_ZST(int *ZST, int *ORD, int *U, int *N){
    CallStackAdd( "ORDER_ZST" );
    int i, j, tmp[*U], start, point;
    
    start = 0;
    for(i=0;i<*N;i++){
        for(j=0;j<*U;j++){
            point = ORD[start + j];
            tmp[j] =  ZST[start + point];
        }
        for(j=0;j<*U;j++){
            ZST[start + j] = tmp[j];
        }
        start = start + *U;
    }
    CallStackRm( "ORDER_ZST" );
}

/* Table_UnitVsHist ************************************************************
*  INPUT:                                                                      *
*    Zst = Essential state vector for state process (labels)                   *
*    N = Number of particles                                                   *
*    U = Number of motor units                                                 *
*    H = location of last state posterior in use                               *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Creates a frequency table of motor unit index vs the posterior density    * 
*    index according to the values defined within Zst. The first U values      *
*    relate to the number of labels that point to the first posterior surface. *
*  FN USED: None                                                               *
*  FN USED BY:                                                                 *
*    Summary_ZST, MyQuantiles_ST_NEW, Reorder_Pmanage                          *
*******************************************************************************/

void Table_UnitVsHist(int *Zst, int *N, int *U, int *H, int *out){
    CallStackAdd( "Table_UnitVsHist" );
    int i, j, size, start, col;
    size = (*U) * (*H);
    
    for(i=0;i<size;i++){
        out[i]=0;
    }
    
    start =0;
    for(i=0;i<*N;i++){
        for(j=0;j<*U;j++){
            col = Zst[start + j];
            out[ col + (j * (*H)) ]++;
        }
        start = start + *U;
    }
    CallStackRm( "Table_UnitVsHist" );
}


/* Marg_Pred *******************************************************************
*  INPUT:                                                                      *
*    weights = predictive probability estimate for each particle (unnormalised)*
*    N = Number of particle in the system                                      *
*    LOG = logical stating whether the output should be logged                 *
*    out = object to return - average weight                                   *
*    pNeff = object to return - effective sample size calculation              *
*  OPERATION:                                                                  *
*    Calculates the marginal predictive probability for the t^th observation   *
*    i.e. P(y_t|y_{t-1},...,y_{1},y_{training},s_{t},...,s_{1},s_{training})   *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/

void Marg_Pred( double *weights, int *N, int *LOG, double *out, double *pNeff){
    CallStackAdd( "Marg_Pred" );
    int i;
    *out = 0;
    *pNeff = 0;
    for(i=0; i<*N; i++){
        *out += weights[i];
        *pNeff += (weights[i] * weights[i]);
    }
    *pNeff = *pNeff / ((*out) * (*out));
    if( *LOG == TRUE ){
        *out = log( *out ) - log( *N );
    }
    else if( *LOG == FALSE ){
        *out = *out / *N;
    }
    else{
        *out = NA_REAL;
        Rprintf("Error in Marg_Pred: 'log' is not logical!\n");
    }
    CallStackRm( "Marg_Pred" );
}

/* Resample ********************************************************************
*  INPUT:                                                                      *
*    weights = the resampling weights for each particle (unnormalised)         *
*    N = Number of particles                                                   *
*    METHOD = the resampling method to perform (either Residual or Mulitnomial)*
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Calculates the resampliong index vector according to the weight of each   *
*    particle. Resampling is performed by multinomial or residual resampling   *
*  FN USED: SimpleResample, StratResample, SysResample                         *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/

void Resample(double *weights, int *N, char **METHOD, int *out){
    CallStackAdd( "Resample" );
    double total, *padj_weights, p, adj_total;
    int i, j, out_i, *ptimes, Rtot,m;
    
    ptimes = (int*)my_malloc( (*N) * sizeof(int) );
    
    total = 0;
    for(i=0; i<*N; i++){
        total = total + weights[i];
        ptimes[i]=0;
    }

    if(strcmp(*METHOD, "Simple") == 0){
        SimpleResample(weights, &total, N, N, ptimes);
    }
    else if(strcmp(*METHOD, "Stratisfied") == 0){
        StratResample(weights, &total, N, N, ptimes);
    }
    else if(strcmp(*METHOD, "Systematic") == 0){
        SysResample(weights, &total, N, N, ptimes);
    }
    else if(strncmp (*METHOD,"R-xx",2) == 0){
        Rtot=0;
        adj_total=0;
        padj_weights = (double*)my_malloc( (*N) * sizeof(double) );
        for(i=0; i<*N; i++){
            p = weights[i]/total;
            ptimes[i] = floor( (*N) * p );
            Rtot += ptimes[i];
            padj_weights[i] = (*N) * p - ptimes[i];
            adj_total += padj_weights[i];
        }
        m = *N-Rtot;
        if(Rtot < *N){
            if(strcmp(*METHOD, "R-Simple") == 0){
                SimpleResample(padj_weights, &adj_total, N, &m, ptimes);
            }
            else if(strcmp(*METHOD, "R-Stratisfied") == 0){
                StratResample(padj_weights, &adj_total, N, &m, ptimes);
            }
            else if(strcmp(*METHOD, "R-Systematic") == 0){
                SysResample(padj_weights, &adj_total, N, &m, ptimes);
            }
            else{
                for(i=0; i<*N; i++){
                    out[i] = NA_REAL;
                }
                Rprintf("RESAMPLE: Method not recognised!\n");
            }
        }
         my_free(padj_weights);
    }
    else{
        for(i=0; i<*N; i++){
            out[i] = NA_REAL;
        }
        Rprintf("RESAMPLE: Method not recognised!\n");
    }

    out_i = 0;
    for(i=0; i<*N; i++){
        for(j=0; j<ptimes[i]; j++){
            out[out_i] = i;
            out_i++;
        }
    }
    
    my_free(ptimes);
   
    CallStackRm( "Resample" );
}

/* SimpleResample **************************************************************
*  INPUT:                                                                      *
*    pweights = the resampling weights for each particle (unnormalised)        *
*    ptotal = sum of pweights                                                  *
*    N = length of pweights                                                    *
*    M = sum of pout                                                           *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Simple multinomial sample                                                 *
*  FN USED: None                                                               *
*  FN USED BY:                                                                 *
*    Resample                                                                  *
*******************************************************************************/

void SimpleResample(double *pweights, double *ptotal, int *N, int *M, int *pout){
    CallStackAdd( "SimpleResample" );
    
    int i, j;
    double v, vkp1, lower;
    vkp1=1;
    j=(*N-1);
    lower = 1 - pweights[j]/(*ptotal);
    for(i=*M; i>0; i--){
        v = vkp1 * pow( runif(0,1), 1/((double)i) );
        vkp1 = v;
        if( v >= lower ){
            pout[j]++;
        }
        else{
            while(v < lower){
                j--;
                lower -= pweights[j]/(*ptotal);
            }
            pout[j]++;
        }
    }
    CallStackRm( "SimpleResample" );
}

/* StratResample ***************************************************************
*  INPUT:                                                                      *
*    pweights = the resampling weights for each particle (unnormalised)        *
*    ptotal = sum of pweights                                                  *
*    N = length of pweights                                                    *
*    M = sum of pout                                                           *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Stratisfied multinomial sample                                            *
*  FN USED: None                                                               *
*  FN USED BY:                                                                 *
*    Resample                                                                  *
*******************************************************************************/

void StratResample(double *pweights, double *ptotal, int *N, int *M, int *pout){
    CallStackAdd( "StratResample" );
    
    int i, j;
    double v, lower;
    j=(*N-1);
    lower = 1 - pweights[j]/(*ptotal);
    for(i=*M; i>0; i--){
        v = runif( (((double)i)-1)/((double)*M), ((double)i)/((double)*M));
        
        if( v >= lower ){
            pout[j]++;
        }
        else{
            while(v < lower){
                j--;
                lower -= pweights[j]/(*ptotal);
            }
            pout[j]++;
        }
    }
    CallStackRm( "StratResample" );
}

/* SysResample *****************************************************************
*  INPUT:                                                                      *
*    pweights = the resampling weights for each particle (unnormalised)        *
*    ptotal = sum of pweights                                                  *
*    N = length of pweights                                                    *
*    M = sum of pout                                                           *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Systematic multinomial sample                                             *
*  FN USED: None                                                               *
*  FN USED BY:                                                                 *
*    Resample                                                                  *
*******************************************************************************/
void SysResample(double *pweights, double *ptotal, int *N, int *M, int *pout){
    CallStackAdd( "SysResample" );
    
    int i, j;
    double v, lower;
    j=(*N-1);
    lower = 1 - pweights[j]/(*ptotal);
    v = runif(1,(((double)*M)+1)/((double)*M));
    for(i=*M; i>0; i--){
        v = v - (1/((double)*M));
        if( v >= lower ){
            pout[j]++;
        }
        else{
            while(v < lower){
                j--;
                lower -= pweights[j]/(*ptotal);
            }
            pout[j]++;
        }
    }
    CallStackRm( "SysResample" );
}

/* Reorder_Pmanage *************************************************************
*  INPUT:                                                                      *
*    pPI = Structure for posterior information                                 *
*    pZst = State process subset of the essential state vector                 *
*    pU = Number of motor units                                                *
*    pN = Number of particles                                                  *
*  OPERATION:                                                                  *
*    After perfroming the resampling step, this command assesses which of the  *
*    state parameter posterior densities are still being used. For those that  *
*    are not, a FALSE is returned in the corresponding element of the output   *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/

void Reorder_Pmanage( PostInfo *pPI, int *pZst, int *pU, int *pN ){
    CallStackAdd( "Reorder_Pmanage" );
    int *pTable, h, j, Using;
    
    pTable = (int *)my_malloc( (*pU) * (pPI->nallocated) * sizeof(int));
    Table_UnitVsHist( pZst, pN, pU, &(pPI->nallocated), pTable);
    
    for(h=0;h<(pPI->nallocated);h++){
        if( pPI->pInUse[h] == TRUE ){
            Using=FALSE;
            j=0;
            while( j<(*pU) && Using==FALSE ){
                if(pTable[(j * (pPI->nallocated))+h]>0){
                    Using = TRUE;
                }
                j++;
            }
            if(Using==FALSE){
                NotInUsePostInfo( pPI, h );
            }
        }
    }
    my_free(pTable);
    CallStackRm( "Reorder_Pmanage" );
}

/* Reorder_Zobs ****************************************************************
*  INPUT:                                                                      *
*    zeta = index vector from the resampling of the particles                  *
*    Zobs = Observation process subset of the essential state vector           *
*    N = Number of particles                                                   *
*    dZobs = length of Zobs for a single particle                              *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Replicates the information in Zobs according to the particle resampling   *
*    index zeta.                                                               *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/

void Reorder_Zobs(int *zeta, double *Zobs, int *N, int *dZobs, double *out){
     CallStackAdd( "Reorder_Zobs" );
     int i, j, start_out, start_zeta;
     for(i=0; i<*N; i++){
         start_out = i * (*dZobs);
         start_zeta = zeta[i] * (*dZobs);
         for(j=0; j<*dZobs; j++){
             out[start_out+j] = Zobs[start_zeta+j];
         }
     }
     CallStackRm( "Reorder_Zobs" );
}

/* Reorder_Zst *****************************************************************
*  INPUT:                                                                      *
*    zeta = index vector from the resampling of the particles                  *
*    Zst = State process subset of the essential state vector                  *
*    N = Number of particles                                                   *
*    u = Number of motor units                                                 *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Replicates the information in Zst according to the particle resampling    *
*    index zeta.                                                               *
*  FN USES: None                                                               *
*  FN USED BY:                                                                 *
*    MUNE_U                                                                    *
*******************************************************************************/

void Reorder_Zst(int *zeta, int *Zst, int *N, int *u, int *out){
     CallStackAdd( "Reorder_Zst" );
     int i, j, start_out, start_zeta;
     for(i=0; i<*N; i++){
         start_out = i * (*u);
         start_zeta = zeta[i] * (*u);
         for(j=0; j<*u; j++){
             out[start_out+j] = Zst[start_zeta+j];
         }
     }
     CallStackRm( "Reorder_Zst" );
}

/* SampleKi_V2 *****************************************************************
*  INPUT:                                                                      *
*    probi = P(y_t,k_t|Z_{t-1}^{(i)}) for all k in K and the ith particle      *
*    kdim = dimension of the firing index vector space (2^u)                   *
*    u = Number of motor units                                                 *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Sampling the firing index vector for a given particle. sampling is perform*
*    by sumulating 'sim' uniformally in [0,1] and evaluate the relevant event  *
*    using the inversion method.                                               *
*  FN USED: None                                                               *
*  FN USED BY:                                                                 *
*    SampleK                                                                   *
*******************************************************************************/

void SampleKi_V2(double *probi, int *kdim, int *u, int *out){
    CallStackAdd( "SampleKi_V2" );
    int i, d;
    double cprob[*kdim], sim;
    
    cprob[0] = probi[0];
    out[0] = 0;
    for(i=1;i<*kdim;i++){
        cprob[i] = cprob[i-1] + probi[i];
        if(i<*u){
            out[i] = 0;
        }
    }
        
    sim = runif(0, cprob[*kdim-1]);
    
    i=0;
    while( sim > cprob[i] ){
        out[0]++;
        for(d=0;d<(*u-1);d++){
            if(out[d]==2){
                out[d+1]++;
                out[d] = 0;
            }
        }
        i++;
    }
    CallStackRm( "SampleKi_V2" );
}

/* SampleK *********************************************************************
*  INPUT:                                                                      *
*    probs = P(y_t,k_t|Z_{t-1}^{(i)}) for all k in K and i = 1,...,N           *
*    zeta = index vector from the resampling of the particles                  *
*    N = Number of particles                                                   *
*    Kdim = dimension of the firing index vector space (2^u)                   *
*    u = Number of motor units                                                 *
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Wrapper for the sampling the firing index vector for each particle        *
*  FN USED:                                                                    *
*    SampleKi_V2                                                               *
* FN USED BY:                                                                  *
*    MUNE_U                                                                    *
*******************************************************************************/

void SampleK( double *probs, int *zeta, int *N, int *Kdim, int *u, int *out){
    CallStackAdd( "SampleK" );
    int i, start_in, start_out;

    start_out = 0;
    for(i=0;i<*N;i++){
        start_in = zeta[i] * (*Kdim);
        SampleKi_V2(&(probs[start_in]), Kdim, u, &(out[start_out]));
        start_out = start_out + *u;
    }
    CallStackRm( "SampleK" );
}

/* THRESHOLD *******************************************************************
*  INPUT:                                                                      *
*    ppFN = name of threshold function                                         *
*    x = quantile value for which to calculate the actication probability      *
*    pG = grid in state parameter space                                        *
*    pGnpts = overall number of points in grid                                 *
*    pFixParams = logical - evaluate based on fix parameter values?            *
*    pLOG = Logical stating whether the output should be logged                *
*    pnout = length of pout -> if(pFixParams==T){length(x)}else{pGnpts}        *
*    pout = object to return                                                   *
*  OPERATION:                                                                  *
*    Wrapper for the threshold function. Only Log-Logistic and Gaussian are    *
*    accepted.                                                                 *
*  FN USES:                                                                    *
*     LogLogisticSigmoid, GaussianSigmoid                                      *
*  FN USED BY:                                                                 *
*     Initialise_P0_V3, Prob_Fire_V2, Update_P, SIMULATE_FIRE_VEC              *
*******************************************************************************/

void THRESHOLD( char **ppFN, double *px, double *pG, int *pGnpts,
        int *pFixParams, int *pLOG, int *pnout, double *pout){
    CallStackAdd( "THRESHOLD" );
    int i;
    if(strcmp(*ppFN, "Log-Logistic") == 0){
        LogLogisticSigmoid( px, &(pG[0]), &(pG[*pGnpts]), pFixParams, pLOG, pnout, pout);
    }
    else if(strcmp(*ppFN, "Gaussian") == 0){
        GaussianSigmoid( px, &(pG[0]), &(pG[*pGnpts]), pFixParams, pLOG, pnout, pout);
    }
    else{
        for(i=0;i<*pnout;i++){
            pout[i] = NA_REAL;
        }
        Rprintf("THRESHOLD: Method not recognised!\n");    
    }
    CallStackRm( "THRESHOLD" );
}

/* GaussianSigmoid *************************************************************
*  INPUT:                                                                      *
*    x = quantile value for which to calculate the actication probability      *
*    loc = location parameter whereby the actication probability is 0.5        *
*    invgrad = inverse gradient evaluated at the location parameter            *
*    calcx = logical argument:                                                 *
*       TRUE - calculate function for all x values for fixed parameters        *
*       FALSE - calculate function at a fixed x for all parameter values       *
*    Log = Logical stating whether the output should be logged                 *
*    nout = number of values to return if(calcx==T){lenght(loc)}else{length(x)}*
*    out = object to return                                                    *
*  OPERATION:                                                                  *
*    Calculates the activation probability according to a Gaussian             *
*    threshold sigmoid. It can calculate values for varying quantile and fixed *
*    parameters or fixed quantile and varying parameters. The latter case is   *
*    the most common use.                                                      *
* FN USES: None                                                                *
* FN USED BY:                                                                  *
*    THRESHOLD                                                                 *
*******************************************************************************/

void GaussianSigmoid( double *x, double *loc, double *invgrad, int *calcx, int *Log, int *nout, double *out)
{
    CallStackAdd( "GaussianSigmoid" );
    int i;
    double sd;
    if(*calcx == 1){
        //Fixed parameters & many points
        for(i=0; i<*nout; i++){
            if( (*loc == x[i]) && ( *invgrad == 0 )){
                out[i] = 0.5;
                if(*Log==1){
                    out[i] = log( out[i] );
                }
            }
            else{
                sd = *invgrad * M_1_SQRT_2PI;
                out[i] = pnorm( x[i], *loc, sd, TRUE, *Log );
            }
        }
    }
    else{
        //many parameters & fixed point
        for(i=0; i<*nout; i++){
            if( (loc[i] == *x) && (invgrad[i] == 0 )){
                out[i] = 0.5;
                if(*Log==1){
                    out[i] = log( out[i] );
                }
            }
            else{
                sd = invgrad[i] * M_1_SQRT_2PI;
                out[i] = pnorm( *x, loc[i], sd, TRUE, *Log );
            }
        }
    }
    CallStackRm( "GaussianSigmoid" );
}

/* ProbCheck *******************************************************************
*  INPUT:                                                                      *
*    pprobs = vector of probabilities to validate                              *
*    pInUse = logical - states whether the associated probability is in use    *
*    pn = length of pprobs                                                     *
*  OPERATION:                                                                  *
*    Due to numerical integration to calcuate probabilities, there is a small  *
*    chance that the evaluated number is outside the permissible [0,1] range.  *
*    This identifies such cases and correct them to the applicable limit value *
* FN USES: None                                                                *
* FN USED BY:                                                                  *
*    MUNE_U                                                                 *
*******************************************************************************/

void ProbCheck( double *pprobs, int *pInUse, int *pn ){
    CallStackAdd( "ProbCheck" );
    int i;
    for(i=0;i<*pn;i++){
        if( pInUse[i] == TRUE ){
            if(ISNAN(pprobs[i])){
                Rprintf("Error: An NaN probability was about to be used! (May need to manually stop code.)");
                return;
            }
            else if(log(pprobs[i])>0){
                pprobs[i]=1.0;
            }
            else if(log(1-pprobs[i])>0){
                pprobs[i]=0.0;
            }
        }
    }
    CallStackRm( "ProbCheck" );
}

/* CallStackAdd ****************************************************************
*  INPUT:                                                                      *
*    pName = String containing the command name                                *
*  OPERATION:                                                                  *
*    Adds the name of the current command to the call stack                    *
* FN USES: None                                                                *
* FN USED BY: All                                                              *
*******************************************************************************/

void CallStackAdd( char *pName ){
    istack--;
    strcpy( &(pcallstack[istack]), pName);
    istack += strlen(pName);
    strcpy( &(pcallstack[istack]), "\n\0");
    istack += 2;    
}

/* CallStackRm *****************************************************************
*  INPUT:                                                                      *
*    pName = String containing the command name                                *
*  OPERATION:                                                                  *
*    Removes the name of the current command to the call stack                 *
* FN USES: None                                                                *
* FN USED BY: All                                                              *
*******************************************************************************/

void CallStackRm( char *pName ){
    istack -= 2;
    strcpy( &(pcallstack[istack]), "\0");
    
    istack -= strlen(pName);
    if( strcmp(&(pcallstack[istack]), pName) == 0 ){
        strcpy( &(pcallstack[istack]), "\0");
        istack += 1;
    }
    else{
        error("\"%s\" is not the last command on the call stack. Call stack:%s\n", pName, pcallstack);
    }
}


/* my_malloc *******************************************************************
*  INPUT:                                                                      *
*    n = The size of memory to allocate                                        *
*  OPERATION:                                                                  *
*    Allocates memory and performs an error chech to ensure the NULL point is  *
*    not returned.                                                             *
* FN USES: None                                                                *
* FN USED BY: All                                                              *
*******************************************************************************/

void *my_malloc(size_t n){
    CallStackAdd( "my_malloc" );
    void *p = malloc(n);
    if( p == NULL){
        error("Unable to allocate %d bytes. Call stack:%s",n,pcallstack);
    }
    CallStackRm( "my_malloc" );
    return p;
}

/* my_free *********************************************************************
*  INPUT:                                                                      *
*    p = Pointer to allocated memory to free                                   *
*  OPERATION:                                                                  *
*    Assesses that the pointer is not NULL and frees the memory using a pointer*
* FN USES: None                                                                *
* FN USED BY: All                                                              *
*******************************************************************************/

void my_free( void *p ){
    CallStackAdd( "my_free" );
    if( p == NULL ){
        error("Attempting to free allocated memory using pointer to NULL. Call stack:%s",pcallstack);
    }
    else{
        free(p);
    }
    CallStackRm( "my_free" );
}

/* NoGrids *********************************************************************
*  INPUT:                                                                      *
*    PI = Posterior information structure                                      *
*  OPERATION:                                                                  *
*    Returns an integer with the number of active excitability parameter       *
*    surfaces.                                                                 *
*  FN USES: None                                                               *
*  FN USED BY: MUNE_U                                                          *
*******************************************************************************/
int NoGrids( PostInfo *pPI ){
    CallStackAdd( "NoGrids" );
    int i, tot;
    tot = 0;
    for(i=0; i<(pPI->nallocated); i++){
        if(pPI->pInUse[i]==TRUE){
            tot++;
        }
    }
    CallStackRm( "NoGrids" );
    return(tot);
}

/*******************************************************************************
Export all information from the essential state vector
*******************************************************************************/

void Export_Zall( double *pZobs, int *pZst, int *pdZobs, int *pN, int *pU){
    
    CallStackAdd( "Export_Zall" );
    int *pDone, i, j, count, cZobs, cZst, h, test, lc, unique;
    FILE *pfile;
     
    pDone = (int *)my_malloc( *pN * sizeof(int));
    for(i=0;i<*pN;i++){
        pDone[i] = 0;
    }
    lc = *pdZobs - 6 - *pU;
    cZobs=0;
    cZst=0;

    pfile = fopen("Zall.txt","w");
    if(pfile==NULL){
        error("Error in opening Zall.txt. Call stack:%s\n",pcallstack);
    }
    fprintf(pfile,"#This file contains the contents of the essential state vector.\n\n");
     
    fprintf(pfile,"\"mb\" \"cb\" \"ab\" \"bb\"");
    for(j=0;j<*pU;j++){
        fprintf(pfile,"\"m_%d\" ",j+1);
    }
    fprintf(pfile,"\"a\" \"b\"");
    for(j=0;j<lc;j++){
        fprintf(pfile," \"c_%d\"",j+1);
    }
    for(j=0;j<*pU;j++){
        fprintf(pfile,"\"lab_%d\" ",j+1);
    }
    fprintf(pfile," \"num\"\n");

    unique=0;
    for(i=0;i<*pN;i++){
        if(pDone[i]==0){
            unique++;
            pDone[i]=1;
            count = 1;
            test = cZst + *pU;
            for(h=(i+1);h<*pN;h++){
                j = 0;
                while( (pZst[cZst+j] == pZst[test+j]) & (j<*pU) ){j++;}
                if(j==*pU){
                    pDone[h] = 1;
                    count++;
                }
                test += *pU;
            }
            fprintf(pfile,"\"%d\"",unique);
            for(j=0;j<*pdZobs;j++){
                fprintf(pfile," %f",pZobs[cZobs+j]);
            }
            for(j=0;j<*pU;j++){
                fprintf(pfile," %d",pZst[cZst+j]);
            }
            fprintf(pfile," %d\n",count);
        }
        cZobs += *pdZobs;
        cZst += *pU;
    }
    fprintf(pfile,"\n");
    fclose(pfile);
    my_free(pDone);
    CallStackRm( "Export_Zall" );
}

/*******************************************************************************
Export Meshes
*******************************************************************************/
void Export_GandPs( PostInfo *pPI, double *pG, int *pGdim ){
    CallStackAdd( "Export_GandPs" );
    
    int i,j,place;
    FILE *pfile;

    pfile = fopen("GandPs.txt","w");
    if(pfile==NULL){
        error("Error in opening GandPs.txt. Call stack:%s\n",pcallstack);
    }
    fprintf(pfile,"#This file contains the contents of the grid and mesh data.\n\n");
    
    fprintf(pfile,"\"vol\"");
    for(j=0;j<(pPI->GridSize);j++){
        fprintf(pfile," \"g_%d\"",j+1);
    }
    fprintf(pfile,"\n");
    place=0;
    for(i=0;i<*pGdim;i++){
        fprintf(pfile,"\"phi_%d\" NA",i+1);
        for(j=0;j<(pPI->GridSize);j++){
            fprintf(pfile," %f",pG[place]);
            place++;
        }
        fprintf(pfile,"\n");
    }
    
    for(i=0;i<(pPI->nmax);i++){
        if((pPI->pInUse)[i] == TRUE){
            fprintf(pfile,"\"%d\"",i);
            fprintf(pfile," %f",(pPI->pNorm)[i]);
            for(j=0;j<(pPI->GridSize);j++){
                fprintf(pfile," %f",((pPI->ppPost)[i])[j]);
            }
            fprintf(pfile,"\n");
        }
    }
    fclose(pfile);
    
    CallStackRm( "Export_GandPs" );
}

/* Export_ZobsNB_curr **********************************************************
*  INPUT:                                                                      *
*    pZobs = Observation process subset of the ESV                             *
*    pZst = State processs subset of the ESV                                   *
*    pdZobs = length of Zobs for one particle                                  *
*    pN = number of particles                                                  *
*    pU = number of motor units                                                *
*    pt = test index                                                           *
*  OPERATION:                                                                  *
*    Identifies each unique particle history and exports the non-baseline part *
*    of the observation process subset of the ESV in order to evaluate quantile*
*    probabilities for prior adjustment.                                       *
*  FN USES: None                                                               *
*  FN USED BY: MUNE_U                                                          *
*******************************************************************************/

void Export_ZobsNB_curr( double *pZobs, int *pZst, int *pdZobs, int *pN, int *pU, int *pt){
    
    CallStackAdd( "Export_ZobsNB_curr" );
    int *pDone, i, j, count, cZobs, cZst, h, test, lc, unique;
    FILE *pfile;
    char filename[20];
     
    pDone = (int *)my_malloc( *pN * sizeof(int));
    for(i=0;i<*pN;i++){
        pDone[i] = 0;
    }
    lc = *pdZobs - 6 - *pU;
    cZobs=0;
    cZst=0;
    
    sprintf(filename, "ZobsNB%d.txt", *pt);
    pfile = fopen(filename,"w");
    if(pfile==NULL){
        error("Error in opening %s. Call stack:%s\n",filename,pcallstack);
    }
    fprintf(pfile,"#This file contains the sufficient statistics for evaluating 'mu-vector' quantile probabilities.\n\n");
     
    for(j=0;j<*pU;j++){
        fprintf(pfile,"\"m_%d\" ",j+1);
    }
    fprintf(pfile,"\"a\" \"b\"");
    for(j=0;j<lc;j++){
        fprintf(pfile," \"c_%d\"",j+1);
    }
    fprintf(pfile," \"num\"\n");

    unique=0;
    for(i=0;i<*pN;i++){
        if(pDone[i]==0){
            unique++;
            pDone[i]=1;
            count = 1;
            test = cZst + *pU;
            for(h=(i+1);h<*pN;h++){
                j = 0;
                while( (pZst[cZst+j] == pZst[test+j]) & (j<*pU) ){j++;}
                if(j==*pU){
                    pDone[h] = 1;
                    count++;
                }
                test += *pU;
            }
            fprintf(pfile,"\"%d\"",unique);
            for(j=4;j<*pdZobs;j++){
                fprintf(pfile," %f",pZobs[cZobs+j]);
            }
            fprintf(pfile," %d\n",count);
        }
        cZobs += *pdZobs;
        cZst += *pU;
    }
    fprintf(pfile,"\n");
    fclose(pfile);
    my_free(pDone);
    CallStackRm( "Export_ZobsNB_curr" );
}


void R_init_SMCMUNE_Cfunctions(DllInfo *info){
  
  R_CMethodDef cMethods[] = {
    {"MUNE_U", (DL_FUNC) &MUNE_U, 29},
    {NULL,NULL,0}
  };
  
  R_registerRoutines(info, cMethods, NULL, NULL, NULL);
  R_useDynamicSymbols(info, TRUE);
}
