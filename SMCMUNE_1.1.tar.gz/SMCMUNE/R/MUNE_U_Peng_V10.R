library("mvtnorm")

MUNE_U<-function(
  DATA, 		       			                  #data as list object (see MUNE_data_format)
  U, 					      	                    #No. MUs
  N=5000, 					                      #Particle set size
  InitalZ=c(0,1e3,0.5,0.1,0,1e3,1), 	  	#mb,v1,ab,bb,m,v2,a
  binfo = c(0.95,0.2),				            #epsilon, p
  Grid.Lower=rep(0,length(Grid.Upper)),    #grid lower limits
  Grid.Upper=c(DATA$Ymax*1.1, 14),         #grid upper limits
  Grid.n=c(30,30)+1, 				              #grid points per axis
  alpha=rep(1.1,length(Grid.Upper)),      #1st shape hyp-param for EC param prior.
  beta=rep(1.1,length(Grid.Upper)), 	 	  #2nd shape hyp-param for EC param prior.
  Integrate="Trapezium_Rule",			        #Integration Method
  Threshold="Log-Logistic", 			        #Excitability curve
  Resample="R-Systematic", 			          #Resampling Method
  Save.GPs=TRUE){ 				                  #Save final G&Ps (req. by rparam)

  TIME <- as.numeric(Sys.time())  ##START TIMER
  
  #Conditions of DATA
  if(!is.list(DATA)){stop("DATA is not a list,")}
  if( !is.numeric(unlist(DATA))){stop("DATA is not numeric")}
  NAMES = names(DATA)
  if( !any(NAMES=="Y") || !any(NAMES=="Ybase") || !any(NAMES=="Ymax") || !any(NAMES=="S") || !any(NAMES=="Sbase") || !any(NAMES=="Smax") ){
    stop("DATA list is not of the required format.")
  }
  if( length(DATA$Y) != length(DATA$S) ){stop("Length of DATA$Y does not equal the length of DATA$S.")}
  if( length(DATA$Ybase) != length(DATA$Sbase) ){stop("Length of DATA$Ybase does not equal the length of DATA$Sbase.")}
  if( length(DATA$Ybase)<2 ){stop("Require at least 2 baseline observations.")}
  if( (length(DATA$Ymax) != 1) || (length(DATA$Smax)!=1)  ){stop("Invalid number of supramaximal observations.")}
  nobs<-length(DATA$Sbase) + length(DATA$Smax) + length(DATA$S)

  #Conditions on the number of motor units
  if( (U%%1 != 0) || (U<=0) ){stop("Invalid value for U.")}

  #Conditions on the number of particles
  if( (N%%1 != 0) || (N<=0) ){stop("Invalid value for N.")}

  #Condition on inital essential state vector definition
  if(length(InitalZ)!=7 || !is.numeric(InitalZ)){stop("Invalid definition for InitalZ.")}
  if(any(InitalZ[-c(1,5)]<0)){stop("InitalZ contains an invalid value.")}
  if(length(binfo)!=2 || !is.numeric(binfo)){stop("Invalid definition for binfo.")}
  if(any(binfo<=0) || (binfo[1]>=1)){stop("binfo contains an invalid value.")}

  #Condition on Grid information
  if( !is.numeric(Grid.Lower) || !is.numeric(Grid.Upper) || !is.numeric(Grid.n)){
    stop("Invalid definition of Grid information.")
  }
  if(length(Grid.Lower)!=length(Grid.Upper) || length(Grid.Lower)!=length(Grid.n)){
    stop("Invalid length of Grid information.")
  }
  if( any(Grid.Lower>Grid.Upper) ){stop("Grid lowerbound must be greater than the upperbound")}
  if( any(Grid.n%%1 != 0) || any(Grid.n < 2) ){ stop("Invaid number of points in the Grids") }

  #Condition on OrdBy (Which Excitability parameter to order the MUs by, given by position in vecor)
  OrdBy = 0L  ##DON'T ORDER. This is unnecessary within fit, only req for rparam.
#  if(!is.numeric(OrdBy) || length(OrdBy)!=1 || (OrdBy%%1 != 0) || OrdBy<0 || OrdBy>length(Grid.Upper)){
#    stop("Invalid definition of OrdBy.")
#  }

  #Conditions on alpha and beta
  if( !is.numeric(alpha) || length(alpha)!=length(Grid.Lower) || any(alpha<=0) ){ stop("Invalid definition for alpha.") }
  if( !is.numeric(beta) || length(beta)!=length(Grid.Lower) || any(beta<=0) ){ stop("Invalid definition for beta") }

  #Conditions on character input
  Integrate.table <- c("Trapezium_Rule","Simpsons_Rule")
  Integrate.id<-pmatch(Integrate,Integrate.table)
  if(is.na(Integrate.id)){stop("Integration method not recognised!")}

  Threshold.table <- c("Log-Logistic","Gaussian")
  Threshold.id<-pmatch(Threshold,Threshold.table)
  if(is.na(Threshold.id)){stop("Threshold function not recognised!")}

  Resample.table <- c("Simple","Stratisfied","Systematic","R-Simple","R-Stratisfied","R-Systematic")
  Resample.id<-pmatch(Resample,Resample.table)
  if(is.na(Resample.id)){stop("Resample method not recognised!")}

  #condition on the write command
  #if(!is.logical(Seq.Adj)){stop("'Seq.Adj' argument must be logical")}
  Seq.Adj = FALSE  #If TRUE, saves Z at each time step (potentially high storage requirements!)
  if(!is.logical(Save.GPs)){stop("'Save.GPs' argument must be logical")}
  ##NOTE: Z at end (Zall.txt) will always be exported!!!
  
  #condition on bound for mu prior adjustment
#  if( length(bound)!=U || !is.numeric(bound) ){stop("'bound' must be a numeric vetor of length U")}

#  #Format where to export
#  if(is.null(dir2C)){dir2C<-getwd()}

#  dyn.load(paste(dir2C,"/MUNE_U_PenV16.so",sep=""))
  RUN<-.C("MUNE_U",
    as.double(DATA$Y),                            #[1]  pY
    as.double(DATA$S),                            #[2]  pS
    as.integer(length(DATA$Y)),                   #[3]  pnobs
    as.double(DATA$Ybase),                        #[4]  pYbase
    as.double(DATA$Sbase),                        #[5]  pSbase
    as.double(DATA$Ymax),                         #[6]  pYmax
    as.double(DATA$Smax),                         #[7]  pSmax
    as.integer(length(DATA$Ybase)),               #[8]  pnbase
    as.integer(U),                                #[9]  pU
    as.integer(N),                                #[10] pN
    as.double(InitalZ),                           #[11] pZstar
    as.double(binfo),                             #[12] pbinfo
    as.double(Grid.Lower),                        #[13] pGlow
    as.double(Grid.Upper),                        #[14] pGupp
    as.integer(Grid.n),                           #[15] pGn
    as.integer(length(Grid.Lower)),               #[16] pGdim
    as.integer(OrdBy-1),                          #[17] pOrdBy
    as.double(alpha),                             #[18] pPalpha
    as.double(beta),                              #[19] pPbeta
    as.character(Integrate.table[Integrate.id]),  #[20] ppIntMethod
    as.character(Resample.table[Resample.id]),    #[21] ppResampMethod
    as.character(Threshold.table[Threshold.id]),  #[22] ppFN
    as.integer(Save.GPs),                         #[23] pexportall
    as.integer(Seq.Adj),                          #[24] pSeqOut
    vector("double",nobs),                        #[25] pout_marg
    vector("double",length(DATA$Y)),              #[26] pNEFF
    vector("integer",length(DATA$Y)),             #[27] pnCurrGrids
    vector("double",1),                           #[28] pb0
    vector("double",1),                           #[29] phatnub
    NAOK=TRUE)
#  dyn.unload(paste(dir2C,"/MUNE_U_PenV16.so",sep=""))

  log.prior <- dgeom(U,0.5,log=TRUE) ###Geometric(1/2) prior distribution
  log.predictives <- RUN[[25]]   ##marginal likelihood factor estimates
  Neff<-RUN[[26]]   #Effective sample size estimate
  no.surfaces<-RUN[[27]]   #Number of unique surfaces
  b0<-RUN[[28]]            ##Derived prior b statisic after baseline
  hatnub<-RUN[[29]]        ##nub median estimate after baseline

  TIME <- as.numeric(Sys.time()) - TIME  #TIME TAKEN TO COMPLETE C CODE
  
  ######################################################################
  ## REDUNDENT: ORTHANT CALCULATION PERFORMED IN SEPORATE FUNCTION!!! ##
  ######################################################################
#  library("parallel")
#  library("foreach")
#  library("doParallel")
#  if(all(bound != -Inf)){
#    #prior correction - prior orthant
#    C<-InitalZ[6]*diag(U)*b0/InitalZ[7]            ##b0 from after baseline rather than at very start!
#    p<-pmvt(lower=bound,upper=rep(Inf,U),delta=rep(InitalZ[5],U),df=2*InitalZ[7],sigma=C)      ##Need to edit this in case the function returns zero!!!
#    if(is.nan(p)){ p<-.Machine$double.eps }
#    if( p < .Machine$double.eps ){ p<-.Machine$double.eps }
#    attributes(p)<-NULL
#    mu.adj.prior<-p
#  
#    #prior correction - posterior orthant
#    print("Processing Adjustment ...")
#    cl <- makeCluster(detectCores() - 1)               #parallel computing within R
#    registerDoParallel(cl, cores = detectCores() - 1)
#  
#    if(Seq.Adj==TRUE){  #Eval orthant prob
#      mu.adj.posterior<-rep(NA,length(DATA$Y)+1)
#      for(i in 0:length(DATA$Y)){
#        filename<-paste("ZobsNB",i,".txt",sep="")
#        zNB<-as.matrix(read.table(filename,skip=2,header=TRUE))
#        mu.adj.posterior[i+1] <- foreach(i = 1:length(zNB[,1]), .combine='+',
#            .packages="mvtnorm") %dopar% {
#  
#             z<-as.numeric(zNB[i,])
#             C<-matrix(NA,ncol=U,nrow=U)
#             C[lower.tri(C,diag=TRUE)]<-z[-c(1:(U+2),length(z))]
#             lowtri<-C[lower.tri(C,diag=FALSE)]
#             C<-t(C)
#             C[lower.tri(C,diag=FALSE)]<-lowtri
#             C<-C*z[U+2]/z[U+1]
#             p<-pmvt(lower=bound,upper=rep(Inf,U),delta=z[1:U],df=2*z[U+1],sigma=C)      ##Need to edit this in case the function returns zero!!!
#             if(is.nan(p)){ p<-.Machine$double.eps }
#             if( p < .Machine$double.eps ){ p<-.Machine$double.eps }
#             attributes(p)<-NULL
#             p*z[length(z)]/N
#           }
#        unlink(filename)
#      }
#    }
#    else{
#      filename<-paste("ZobsNB",length(DATA$Y),".txt",sep="")
#      zNB<-as.matrix(read.table(filename,skip=2,header=TRUE))
#      mu.adj.posterior <- foreach(i = 1:length(zNB[,1]), .combine='+',
#            .packages="mvtnorm") %dopar% {
#  
#             z<-as.numeric(zNB[i,])
#             C<-matrix(NA,ncol=U,nrow=U)
#             C[lower.tri(C,diag=TRUE)]<-z[-c(1:(U+2),length(z))]
#             lowtri<-C[lower.tri(C,diag=FALSE)]
#             C<-t(C)
#             C[lower.tri(C,diag=FALSE)]<-lowtri
#             C<-C*z[U+2]/z[U+1]
#             p<-pmvt(lower=bound,upper=rep(Inf,U),delta=z[1:U],df=2*z[U+1],sigma=C)      ##Need to edit this in case the function returns zero!!!
#             if(is.nan(p)){ p<-.Machine$double.eps }
#             if( p < .Machine$double.eps ){ p<-.Machine$double.eps }
#             attributes(p)<-NULL
#             p*z[length(z)]/N
#  
#           }
#      unlink(filename)
#    }
#    stopCluster(cl)
#    print("Done!")
#  }else{
#    mu.adj.prior <- 1
#    if(Seq.Adj==TRUE){
#      mu.adj.posterior<-rep(1,length(DATA$Y)+1)
#    }else{
#      mu.adj.posterior<-1
#    }
#  }
  
#  TIME[2]<-TIME[2]+unname(proc.time()[1])
  RETURN = list(log.prior=log.prior,
                log.predictives=log.predictives,
                #mu.adj.prior=mu.adj.prior,
                #mu.adj.posterior=mu.adj.posterior,
                no.surfaces=no.surfaces,
                Neff=Neff,
                CompTime=TIME,
                b0=b0,
                hatnub=hatnub)
  return(RETURN)
}
