MUNE<-function(
  DATA,                                ##DATA
  Urange=1:12,                         ##Vector of models to fit, need not be complete set
  N=rep(5000,length(Urange)),          ##Number of particles per model
  n=matrix(30,ncol=2,nrow=length(Urange)), ##Grid cells per model
  Gupper = c(1.1*DATA$Smax,14),        ##Grid upper bounds
  Glower = c(0,0),                     ##Grid lower bounds
  
  m0=40,                               #Twitch parameter statistics
  v=c(1000,10000),
  binfo=c(0.95,0.2),
  
  Alpha=c(1.1,1.1),                    ##EC param statistics
  Beta=c(1.1,1.1),
  
  Resamp.meth="R-Systematic",
  Threshold = "Log-Logistic",
  Save.GPs = FALSE,
  SEED = NULL){
  
  
  ##FILE MANAGEMENT!!!
  oldwd <- getwd()
  DATE <- paste0(strsplit(as.character(Sys.time()),":")[[1]],collapse="-")
  DATE <- paste0(strsplit(DATE," ")[[1]],collapse="_")
  DIR <- paste0("MUNE_",DATE)
  dir.create(DIR)
  
  FILES <- paste("U",Urange,sep="")
  version  <- rep(0,length(Urange))
  if(length(Urange)!=1){
    for(i in 2:length(Urange)){
      j <- which(Urange[1:(i-1)] ==  Urange[i])
      version[i] <- length(j)
    }
  }
  vtxt <- paste0("v",as.character(version))
  vtxt[version==0] <- ""
  FILES <- paste0(FILES,vtxt)
  
  ##STORAGE ARRAYS
  NoObs         <- length(DATA$Y)+length(DATA$Ybase)+length(DATA$Ymax)
  SEQ_PRED      <- matrix(NA, ncol=NoObs+1,        nrow=length(Urange))
  Time          <- matrix(NA, ncol=1,              nrow=length(Urange))
  B0Calc        <- matrix(NA, ncol=2,              nrow=length(Urange))
  rownames(SEQ_PRED) <- FILES
  rownames(Time) <- FILES
  rownames(B0Calc) <- FILES
  colnames(B0Calc) <- c("b0","hatnub")
  
  #FORMAT N
  if(length(N)!=length(Urange)){
    stop("Length of 'N' is not equal to the number of requested models!")
  }
  
  #FORMAT grid size
  if(nrow(n)!=length(Urange)){
    stop("Nrows of 'n' is not equal to the number of requested models!")
  }
  
  if(!is.null(SEED)){
    if(length(SEED)!=length(Urange) | !is.numeric(SEED)) stop("Invalid SEED argument.")
    if(any(SEED<0) | any(SEED%%1 != 0)) stop("Invalid SEED argument.")
  }
  
  
  for(uu in 1:length(Urange)){
    
    u           <- Urange[uu]  #Assumed number of MUs
    NoParticles <- N[uu]       #Number of particles
    NoG         <- n[uu,]      #Grid size
    
    ##FILE MANAGEMENT!!!
    dir.create(paste0(oldwd,"/",DIR,"/",FILES[uu]))
    setwd(paste0(oldwd,"/",DIR,"/",FILES[uu]))

    ##Run model on given number of MUs
    if(!is.null(SEED)) set.seed(SEED[uu])
    INTEGRATE_METHOD <- "Trapezium_Rule"
    RESULT<- MUNE_U(
      DATA,
      u,
      N = NoParticles,
      InitalZ = c(0, v[1], 0.5, 0.1, m0, v[2], 1),
      binfo,
      Grid.Lower=Glower,   
      Grid.Upper=Gupper,  
      Grid.n=NoG + 1,     ### convert #cells to #pts
      alpha=Alpha,
      beta=Beta,
      Integrate = INTEGRATE_METHOD,  #Should only use Trap. method
      Threshold = Threshold,
      Resample = Resamp.meth,
      Save.GPs = Save.GPs)
    
    #STORE Information
    SEQ_PRED[uu,]      <- c(RESULT$log.prior,RESULT$log.predictives)
    Time[uu,]          <- RESULT$CompTime
    B0Calc[uu,]        <- c(RESULT$b0,RESULT$hatnub)
    
    setwd(oldwd)
  
    LPost <- apply(SEQ_PRED,1,sum)
    ORTH <- matrix(1,ncol=2,nrow=length(Urange))
    rownames(ORTH) <- FILES
    colnames(ORTH) <- c("prior","post")
    ORTH_TIME <- matrix(NA,nrow=length(Urange),ncol=1)
    rownames(ORTH_TIME) <- FILES
    OUT <- list(LPost=LPost, TIME=Time, B0=B0Calc, InitalZ = c(0, v[1], 0.5, 0.1, m0, v[2], 1),
              U = Urange, DIR = paste0(oldwd,"/",DIR,"/"), FILES = FILES, SEED=SEED, 
              ORTH = ORTH, mumin = -Inf, ORTH_TIME = ORTH_TIME,
              Integrate = INTEGRATE_METHOD,
              Threshold = Threshold)
    save(OUT, file = paste0(OUT$DIR,"summary_tmp.Rdata"))
  }
  file.rename(paste0(OUT$DIR,"summary_tmp.Rdata"), paste0(OUT$DIR,"summary.Rdata"))
  return(OUT)
}
