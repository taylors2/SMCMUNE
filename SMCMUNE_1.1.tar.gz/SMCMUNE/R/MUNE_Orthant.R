Orthant<-function(z,bound,U){
  if (bound == -Inf) {
    p <- 1
  }else {
    z <- as.numeric(z)
    if(U==1){
      C <- z[-c(1:(U + 6), length(z) - (U:0))]
      p <- pt((bound-z[4 + (1:U)])/sqrt(C), df = 2 * z[U + 5], lower.tail=FALSE)
      if (p < .Machine$double.eps) p <- .Machine$double.eps
    }else{
      C <- matrix(NA, ncol = U, nrow = U)
      C[lower.tri(C, diag = TRUE)] <- z[-c(1:(U + 6), length(z) - (U:0))]
      lowtri <- C[lower.tri(C, diag = FALSE)]
      C <- t(C)
      C[lower.tri(C, diag = FALSE)] <- lowtri
      C <- C * z[U + 6]/z[U + 5]
      p <- pmvt(lower = rep(bound, U), upper = rep(Inf, U), 
          delta = z[4 + (1:U)], df = 2 * z[U + 5], sigma = C)
      if (is.nan(p)) p <- .Machine$double.eps
      if (p < .Machine$double.eps) p <- .Machine$double.eps
      attributes(p) <- NULL
    }
  }
  return(c(p, z[length(z)]))
}

MUNE_Orthant <- function(MUNE, bound=15){
  for(uu in 1:length(MUNE$U)){
    cat("Orthant calculations for",MUNE$FILES[uu],":")
    TIME2 <- as.numeric(Sys.time())
    u <- MUNE$U[uu]
    b <- MUNE$B0[uu,1]
    C <- diag(u)*MUNE$InitalZ[6]*b/MUNE$InitalZ[7]
    p <- pmvt(lower = rep(bound,u), upper = rep(Inf,u), delta = rep(MUNE$InitalZ[5],u), 
              df = 2*MUNE$InitalZ[7], sigma = C)
    if(is.nan(p)) p <- 0
    p <- max(p, .Machine$double.eps)
    attributes(p) <- NULL
    MUNE$ORTH[uu,1] <- p

    file <- paste0(MUNE$DIR,MUNE$FILES[uu],"/Zall.txt")
    Zall <- read.table(file)
    pPost <- apply(Zall,1,Orthant,bound=bound,U=u)
    MUNE$ORTH[uu,2] <- sum(pPost[1,]*pPost[2,])/sum(pPost[2,])
    MUNE$ORTH_TIME[uu] <- as.numeric(Sys.time()) - TIME2
    cat(" done\n")
  }
  MUNE$mumin = bound
  save(MUNE, file = paste0(MUNE$DIR,"summary.Rdata"))
  return(MUNE)
  
}






