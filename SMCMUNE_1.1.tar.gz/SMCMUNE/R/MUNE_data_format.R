MUNE_data_format <- function(Stimulus, Data=NULL, baselineS=0, baselineY=NA){
  if(!is.numeric(Stimulus) & !is.numeric(Data)){stop("Data must be numeric.")}
  if(length(Stimulus)!=length(Data)){stop("Inconsistent lengths.")}
  if(!is.na(baselineS)){
    if(!is.numeric(baselineS)){stop("Baseline limit must be numeric.")}
    if(baselineS<min(Stimulus) | baselineS>max(Stimulus)){stop("Invalid baseline limit.")}
  }
  if(!is.na(baselineY)){
    if(!is.numeric(baselineY)){stop("Baseline limit must be numeric.")}
    if(baselineY<min(Data) | baselineY>max(Data)){stop("Invalid baseline limit.")}
  }
  if(!is.na(baselineY) & !is.na(baselineS)){
    ind.base<-which(Stimulus<=baselineS & Data<=baselineY)
  }else if(!is.na(baselineY) & is.na(baselineS)){
    ind.base<-which(Data<=baselineY)
  }else if(is.na(baselineY) & !is.na(baselineS)){
    ind.base<-which(Stimulus<=baselineS)
  }else{
    stop("Baseline limit not provided.")
  }
  if(length(ind.base)<2){warning("length(S.base) < 2.")}
  ind.max<-which(Stimulus==max(Stimulus))[1]
  ind<-(1:length(Stimulus))[-c(ind.base,ind.max)]
  reord<-order(Stimulus[ind])
  ind<-ind[reord]
  l<-list(Sbase=Stimulus[ind.base],S=Stimulus[ind],Smax=Stimulus[ind.max],
          Ybase=Data[ind.base],Y=Data[ind],Ymax=Data[ind.max])
  return(l)
}
