getGindicies <- function(Gfile){
  ##get unique mesh indicies (ks)
  con <- file(Gfile,"r")
  Gindex <- NULL
  search <- TRUE
  get <- FALSE
  while(search){
    char <- readChar(con=con, nchars = 1)
    if(length(char)==0){
      search <- FALSE
    }else if(char=="\"" & get==FALSE){
      get <- TRUE
      txt <- NULL
    }else if(char=="\"" & get==TRUE){
      get <- FALSE
      Gindex <- c(Gindex,paste0(txt,collapse=""))
    }else if(get==TRUE){
      txt <- c(txt,char)
    }
  }
  close(con)
  gdim <- sum(grepl("phi",Gindex))
  gsize <- sum(grepl("g_",Gindex))
  Gindex <- as.numeric(Gindex[!grepl("[a-z]",Gindex)])
  return(list(gdim=gdim,id=Gindex,size=gsize))
}


SampleSurface <- function(size, P, PHI){
  #sample from 2d surface with linear interpolation
  #Method - 1) sample cell wrt volume under interpolated surface (2d trapezium)
  #       - 2) Draw point via rejection sampling with uniform envelop (redo 1) if rejected)

  if(length(PHI)!=2) stop("Implemented method only valid for 2D surfaces.")
  P <- matrix(P,nrow=length(PHI[[1]]),ncol=length(PHI[[2]]))
  h1 <- diff(range(PHI[[1]]))/(length(PHI[[1]])-1)
  h2 <- diff(range(PHI[[2]]))/(length(PHI[[2]])-1)
  subvol <- (P[-1,-1] + P[-1,-ncol(P)] + P[-nrow(P),-1] + 
                P[-nrow(P),-ncol(P)])*h1*h2/4
  DRAW <- matrix(NA,nrow=size,ncol=2)
  for(i in 1:size){
    while(is.na(DRAW[i,1])){
      cell <- sample(1:length(subvol),size=1,prob=subvol)
      row = (cell-1)%%nrow(subvol) + 1
      col = (cell-row)/nrow(subvol) + 1
      prop <- runif(2)
      acceptProb <- ((1-prop[1])*(1-prop[1])*P[row,col] + (1-prop[1])*prop[2]*P[row,col+1] + 
        prop[1]*(1-prop[2])*P[row+1,col] + prop[1]*prop[2]*P[row+1,col+1]) / 
        max(P[row+c(0,1),col+c(0,1)])
      if(runif(1)<acceptProb){
        DRAW[i,] <- c(qunif(prop[1],PHI[[1]][row],PHI[[1]][row+1]),
                      qunif(prop[2],PHI[[2]][col],PHI[[2]][col+1]))
      }
    }
  }
  return(DRAW)
}


MUNE_rparam <- function(size, MUNE, case=1, order=1, ECparams=TRUE, limit = 0.0001){
  
  TIME1 <- as.numeric(Sys.time())
  
  if(length(size)!=1 | !is.numeric(size)) stop("Invalid size argument.")
  if(size%%1 != 0 | size<=0) stop("Invalid size argument.")
  if(length(case)!=1 | !is.numeric(case)) stop("Invalid case argument.")
  if(case%%1 != 0 | case<=0 | case>length(MUNE$FILES)) stop("Invalid case argument.")
  Zfile <- paste0(MUNE$DIR,MUNE$FILES[case],"/Zall.txt")
  if(!file.exists(Zfile)) stop(paste0("File ", Zfile, " does not exist."))
  if(length(ECparams)!=1 | !is.logical(ECparams)) stop("Invalid ECparams argument.")
  if(ECparams){
    Gfile <- paste0(MUNE$DIR,MUNE$FILES[case],"/GandPs.txt")
    if(MUNE$Integrate!="Trapezium_Rule")
      stop("Integration/Interpolation method only supported for 'Trapezium_Rule'.")
    if(!file.exists(Gfile)){
      warning("File ", Gfile, " does not exist. Cannot sample ECparams.")
      ECparams <- FALSE
    }
  }
  if(length(order)!=1 | !is.numeric(order)) stop("Invalid order argument.")
  if(order%%1 != 0) stop("Invalid order argument.") ##If order<=0 | order>dim(G) then default order on m statistic
  
  if(MUNE$ORTH[case,2] < limit) stop("Low acceptance rate!")
  
  U <- MUNE$U[case]
  bound <- MUNE$mumin
  
  ###SAMPLE TWITCH PARAMS
  #Zfile <- "D:/BACK_UP_27112017/02 PHD/RealSave_06042017/DATA.SET.R10.save/U3/RUN1/Zall.txt"
  Zall <- read.table(Zfile)
  N<-Zall[,ncol(Zall)]
  wt <- N/sum(N)
  
  SAMPLE<-matrix(NA,ncol=4+U,nrow=size)
  ORD <- matrix(1:U,nrow=size,ncol=U,byrow=TRUE)
  i=1
  while(i<=size){
    ##Sample particle kernel
    particle<-sample(1:length(N),1,prob=wt)
    ##within MU variance parameter
    nu<-1/rgamma(1,shape=Zall[particle,U+5],rate=Zall[particle,U+6])
    #Reconstruct C sufficient matrix statistic
    Cmat<-diag(U)
    Cmat[lower.tri(Cmat,diag=T)]<-as.numeric(Zall[particle,U+6+ (1:(U*(U+1)*0.5))])
    Ctmp<-Cmat[lower.tri(Cmat)]
    Cmat<-t(Cmat)
    Cmat[lower.tri(Cmat)]<-Ctmp
    M <- as.numeric(Zall[particle,4+(1:U)])
    ##Expected MUTF parameter
    MU <- rmvnorm(1,mean=M,sigma=Cmat*nu)
    if(all(MU>=bound)){
      ##ordering on M statistic (default)
      if(order==0) ORD[i,] <- order(M)
      ##Baseline variance parameter
      nub<-1/rgamma(1,shape=Zall[particle,3],rate=Zall[particle,4])
      ##Baseline expectation parameter
      mub<-rnorm(1,Zall[particle,1],sqrt(Zall[particle,2]*nub))
      SAMPLE[i,]<-c(particle,mub,nub,nu,MU[ORD[i,]])
      i<-i+1
    }
  }
  
  if(!ECparams){
    #Return samples
    colnames(SAMPLE) <- c("ParticleID","mu_base","var_base","var_within",paste0("mu_",1:U))
    rownames(SAMPLE) <- NULL
    attr(SAMPLE, "U") <- U
    attr(SAMPLE, "FILE") <- MUNE$FILES[case]
    attr(SAMPLE, "TIME") <- as.numeric(Sys.time()) - TIME1
    return(SAMPLE[,-1])
  }
  
  ###SAMPLE EC PARAMS
  
  #Gfile <- "D:/BACK_UP_27112017/02 PHD/RealSave_06042017/DATA.SET.R10.save/U3/RUN1/GandPs.txt"
  tmp <- getGindicies(Gfile)
  gdim <- tmp$gdim
  Gindex <- tmp$id
  Gsize <- tmp$size
  rm(tmp)
  
  Ks <- matrix(NA,nrow=size,ncol=U)
  Zkcols <- ncol(Zall)-U-1+(1:U)
  for(i in 1:size) Ks[i,] <- as.numeric(Zall[SAMPLE[i,1],Zkcols])[ORD[i,]]
  TABk <- table(as.numeric(Ks))
  Kindex <- as.numeric(names(TABk))
  
  SAMPLE.PHI <- matrix(NA,nrow=size,ncol=gdim*U)
  PHI <- NULL
  WT <- rep(1,Gsize)
  axvals <- matrix(NA,nrow=gdim,ncol=Gsize)
  for(i in 1:gdim){
    axvals[i,] <- as.numeric( read.table(file=Gfile,skip = 2+i,nrows = 1)[1,-(1:2)] )
    PHI[[i]] <- sort(unique(axvals[i,]))
    edge <- which(axvals[i,] %in% range(PHI[[i]]))
    WT[edge] <- WT[edge]*0.5
  }

  h <- 1
  for(j in 1:gdim) h <- h * diff(range(PHI[[j]]))/(length(PHI[[j]])-1)

  EXP <- matrix(NA,ncol=gdim,nrow=length(Kindex))
  for(i in 1:length(Kindex)){
    kk <- which(Kindex[i]==Gindex)
    tmp <- read.table(file=Gfile,skip = 4+kk,nrows = 1)
    lP <- as.numeric(tmp[1,-(1:2)])
    rm(tmp)
    P <- exp(lP - max(lP))
    draw <- SampleSurface(size=as.numeric(TABk[i]), P, PHI)
    dr <- 1; r <- 1
    while(dr<=nrow(draw)){
      for(j in 1:U){
        if(Ks[r,j]==Kindex[i]){
          SAMPLE.PHI[r,j] <- draw[dr,1]
          SAMPLE.PHI[r,U+j] <- draw[dr,2]
          dr <- dr+1
        }
      }
      r <- r+1
    }
    A <- sum(P*WT)*h
    for(j in 1:gdim)  EXP[i,j] <- sum(P*WT*axvals[j,])*h/A
  }
  
  
  
  if(order %in% (1:nrow(EXP))){
    ##re-order samples based on chosen ECparam expectation
    for(i in 1:size){
      Kid <- sapply(Ks[i,],function(a){which(a==Kindex)})
      reord <- order(EXP[Kid,order])
      for(j in 1:gdim){
        SAMPLE.PHI[i,(j-1)*U + (1:U)] <- SAMPLE.PHI[i,(j-1)*U + (reord)]  #EC params
      }
      SAMPLE[i,4+(1:U)] <- SAMPLE[i,4+reord]            #mu params
    }
  }
  
  SAMPLE <- cbind(SAMPLE,SAMPLE.PHI)
  NAMES <- c("ParticleID","mu_base","var_base","var_within",paste0("mu_",1:U))
  for(j in 1:gdim) NAMES <- c(NAMES,paste0("phi",j,"_",1:U))
  colnames(SAMPLE) <- NAMES
  rownames(SAMPLE) <- NULL
  attr(SAMPLE, "U") <- U
  attr(SAMPLE, "FILE") <- MUNE$FILES[case]
  attr(SAMPLE, "TIME") <- as.numeric(Sys.time()) - TIME1
  return(SAMPLE[,-1])
  
}


